package multimain;

import org.springframework.context.ApplicationContext;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;

public class MultiThreadExecutor {
	public TaskExecutor executor;
	public static int threadCount;
	//�첽��������߳�
	public void executeTasks(ApplicationContext contextMulti){
		//System.out.println("+++++");
		TodoDistributorThread fillTask=contextMulti.getBean("fillTask", TodoDistributorThread.class);
		executor.execute(fillTask);
		//System.out.println("====");
		for(int i=0;i<threadCount;i++){
			SimpleTask task= contextMulti.getBean("SimpleTask", SimpleTask.class);
			task.setThreadNo(i);
			executor.execute(task);
		}
	}
	public void start(ApplicationContext contextMulti){
		MultiThreadExecutor ee=new MultiThreadExecutor();
		ee.setExecutor(new SimpleAsyncTaskExecutor());
		ee.executeTasks(contextMulti);
	}
	
	public TaskExecutor getExecutor() {
		return executor;
	}

	public void setExecutor(TaskExecutor executor) {
		this.executor = executor;
	}
	public int getThreadCount() {
		return threadCount;
	}
	public void setThreadCount(int threadCount) {
		this.threadCount = threadCount;
	}


	
}
