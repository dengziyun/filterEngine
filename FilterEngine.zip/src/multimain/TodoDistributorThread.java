package multimain;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.hctc.crawler.common.CommRef;
import com.hctc.crawler.common.LinkedListListOp;

public class TodoDistributorThread implements Runnable {
	public static int threadCount; 
	public static LinkedList<LinkedList> linkedListList= new LinkedList<LinkedList>();
	public CommRef commRef;
	public LinkedListListOp listListOp;
	@Override
	public void run() {//����������̵߳Ķ�����д��������б�
		while(true){
			//ȷ��������threadCount��ListԪ�أ��൱�ڳ�ʼ��
			for(int i=0;i<threadCount;i++){
				if(linkedListList==null)  
					linkedListList.addLast(new LinkedList<String>());
				if(linkedListList.size()<threadCount) linkedListList.addLast(new LinkedList<String>());
			}
			//��TodoList��ȡ��һ��������̵Ķ����У���ȷ��ÿ�����г���ΪthreadCount
			LinkedList list=listListOp.findShortestLinkedList(linkedListList);
			if(list.size()<threadCount){
				String pageStr=commRef.dbTodoUtil.getFirstItem();
				if(pageStr!=null&&!pageStr.isEmpty()){
					list.add(pageStr);	
				}
				commRef.dbTodoUtil.deleteFromDatabase(pageStr);
			}
		}
		
	}






	public LinkedListListOp getListListOp() {
		return listListOp;
	}
	public void setListListOp(LinkedListListOp listListOp) {
		this.listListOp = listListOp;
	}

	public static LinkedList<LinkedList> getLinkedListList() {
		return linkedListList;
	}
	public static void setLinkedListList(LinkedList<LinkedList> linkedListList) {
		TodoDistributorThread.linkedListList = linkedListList;
	}
	public CommRef getCommRef() {
		return commRef;
	}
	public void setCommRef(CommRef commRef) {
		this.commRef = commRef;
	}
	public static int getThreadCount() {
		return threadCount;
	}
	public static void setThreadCount(int threadCount) {
		TodoDistributorThread.threadCount = threadCount;
	}

}
