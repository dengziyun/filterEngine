package multimain;

import java.util.Date;
import java.util.LinkedList;

import com.hctc.crawler.common.CommRef;
import com.hctc.crawler.common.CommUtil;
import com.hctc.crawler.page.DownPage;

public class SimpleTask implements Runnable {
	public int threadNo;
	public DownPage down;
	public CommRef commRef;
	public static int count=0;

	@Override
	public void run() {
		int i=1;
		while(true){
			try{
				String pageStr = new String();
				String logStr = new String();
				long a = new Date().getTime();
				long b = new Date().getTime();
				//System.out.println(commRef.dbTodoUtil.count());
				if (commRef.dbTodoUtil.count() == 0 && threadNo==0) {
					//System.out.println("start===="+commRef.firstUrl);
					pageStr = commRef.firstUrl;
					down.setPageUrl(pageStr);
					down.downPage();
				}
				LinkedList<LinkedList> listList=TodoDistributorThread.getLinkedListList();
				if(listList!=null){
					if(listList.size()>threadNo&&listList.get(threadNo)!=null&&listList.get(threadNo).size()>0){
						LinkedList<String> list=listList.get(threadNo);
						pageStr=new String(list.getFirst());
						if (pageStr != null && !pageStr.isEmpty()) {
							down.setPageUrl(pageStr);
							//������ҳ
							down.downPage();
							//ɾ�������ص���ҳ
							list.removeFirst();
							count++;
							if(count%100==0) 
								System.out.println(count+"====="+threadNo+"=========todo:" + commRef.dbTodoUtil.count()
									+ "=========visited:" + commRef.dbVisitedUtil.count());
						}else{
							list.removeFirst();
						}
						
					}
				}
				i++;
				//System.out.println(listList);
			}catch (Exception e) {
				e.printStackTrace();
			}
			
		}

	}

	public DownPage getDown() {
		return down;
	}

	public void setDown(DownPage down) {
		this.down = down;
	}

	public CommRef getCommRef() {
		return commRef;
	}

	public void setCommRef(CommRef commRef) {
		this.commRef = commRef;
	}

	public int getThreadNo() {
		return threadNo;
	}

	public void setThreadNo(int threadNo) {
		this.threadNo = threadNo;
	}
	
	
}
