package multimain;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class StartMultiCrwaler {

	public static void main(String[] args) {
		ApplicationContext contextMulti = new ClassPathXmlApplicationContext("multimain/BeanConfig.xml");
		MultiThreadExecutor multiCrawler= contextMulti.getBean("multiCrawler", MultiThreadExecutor.class);
		multiCrawler.start(contextMulti);

	}

}
