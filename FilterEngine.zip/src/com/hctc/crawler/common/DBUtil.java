package com.hctc.crawler.common;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import com.sleepycat.bind.EntryBinding;
import com.sleepycat.bind.serial.SerialBinding;
import com.sleepycat.bind.serial.StoredClassCatalog;
import com.sleepycat.je.Cursor;
import com.sleepycat.je.CursorConfig;
import com.sleepycat.je.Database;
import com.sleepycat.je.DatabaseConfig;
import com.sleepycat.je.DatabaseEntry;
import com.sleepycat.je.Environment;
import com.sleepycat.je.EnvironmentConfig;
import com.sleepycat.je.LockConflictException;
import com.sleepycat.je.LockMode;
import com.sleepycat.je.OperationStatus;
import com.sleepycat.je.Transaction;
import com.sleepycat.je.TransactionConfig;

public class DBUtil {

	// ���ݿ⻷��
	public Environment env = null;

	// ���ݿ�
	public Database frontierDatabase = null, classDb = null;

	// ���ݿ���
	public String dbName = "frontier_database";
	public String classDbName = "classDb";

	public StoredClassCatalog classCatalog;

	public DBUtil(String homeDirectory) {

		// 1������EnvironmentConfig
		EnvironmentConfig envConfig = new EnvironmentConfig();
		envConfig.setTransactional(true);
		envConfig.setAllowCreate(true);
		envConfig.setCacheSize(100000);// ���ݿ⻺���С

		// 2��ʹ��EnvironmentConfig����Environment
		File file = new File(homeDirectory);
		if (!file.exists() && !file.isDirectory())
			file.mkdir();
		env = new Environment(new File(homeDirectory), envConfig);

		// 3������DatabaseConfig
		DatabaseConfig dbConfig = new DatabaseConfig();
		dbConfig.setTransactional(true);
		dbConfig.setAllowCreate(true);

		// 4��ʹ��Environment��DatabaseConfig��Database
		frontierDatabase = env.openDatabase(null, dbName, dbConfig);
		classDb = env.openDatabase(null, classDbName, dbConfig);

		classCatalog = new StoredClassCatalog(classDb);

	}

	/*
	 * �����ݿ���д���¼�����ж��Ƿ�������ظ����ݡ� ����key��value
	 * ���������ظ����ݣ���ֱ��ʹ��put()���ɣ����������ظ����ݣ���ʹ��putNoOverwrite()��
	 */
	public boolean writeToDatabase(String key, Page value, boolean isOverwrite) {
		try {
			// ����key/value,ע��DatabaseEntry��ʹ�õ���bytes����
			DatabaseEntry theKey = new DatabaseEntry(key.getBytes("UTF-8"));
			DatabaseEntry theData = new DatabaseEntry();
			EntryBinding dataBinding = new SerialBinding(classCatalog, Page.class);
			dataBinding.objectToEntry(value, theData);
			OperationStatus status = null;
			Transaction txn = null;
			try {
				// 1��Transaction����
				TransactionConfig txConfig = new TransactionConfig();
				txConfig.setSerializableIsolation(true);
				txn = env.beginTransaction(null, txConfig);
				// 2��д������
				if (isOverwrite) {
					status = frontierDatabase.put(txn, theKey, theData);
				} else {
					status = frontierDatabase.putNoOverwrite(txn, theKey, theData);
				}
				txn.commit();
				if (status == OperationStatus.SUCCESS) {
					// System.out.println("�����ݿ�" + dbName + "��д��:" + key + "," +
					// value);
					return true;
				} else if (status == OperationStatus.KEYEXIST) {
					System.out.println("�����ݿ�" + dbName + "��д��:" + key + "," + value + "ʧ��,��ֵ�Ѿ�����");
					return false;
				} else {
					System.out.println("�����ݿ�" + dbName + "��д��:" + key + "," + value + "ʧ��");
					return false;
				}
			} catch (LockConflictException lockConflict) {
				txn.abort();
				System.out.println("�����ݿ�" + dbName + "��д��:" + key + "," + value + "����lock�쳣");
				return false;
			}
		} catch (Exception e) {
			// ������
			System.out.println("�����ݿ�" + dbName + "��д��:" + key + "," + value + "���ִ���");
			return false;
		}
	}

	/*
	 * �����ݿ��ж������� ����key ����value
	 */
	public Page readFromDatabase(String key) {
		try {
			DatabaseEntry theKey = new DatabaseEntry(key.getBytes("UTF-8"));
			DatabaseEntry theData = new DatabaseEntry();
			EntryBinding dataBinding = new SerialBinding(classCatalog, Page.class);
			Transaction txn = null;
			try {
				// 1������ Transaction�����Ϣ
				TransactionConfig txConfig = new TransactionConfig();
				txConfig.setSerializableIsolation(true);
				txn = env.beginTransaction(null, txConfig);
				// 2����ȡ����
				OperationStatus status = frontierDatabase.get(txn, theKey, theData, LockMode.DEFAULT);
				txn.commit();
				if (status == OperationStatus.SUCCESS) {
					// 3�����ֽ�ת����String
					Page page = (Page) dataBinding.entryToObject(theData);
					return page;
				} else {
					// System.out.println("No record found for key '" + key +
					// "'.");
					return null;
				}
			} catch (LockConflictException lockConflict) {
				txn.abort();
				System.out.println("�����ݿ�" + dbName + "�ж�ȡ:" + key + "����lock�쳣");
				return null;
			}

		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			return null;
		}
	}

	/*
	 * �������ݿ��е����м�¼������list
	 */
	public ArrayList<String> getEveryItem() {
		// TODO Auto-generated method stub
		// System.out.println("===========�������ݿ�" + dbName + "�е���������==========");
		Cursor myCursor = null;
		ArrayList<String> resultList = new ArrayList<String>();
		Transaction txn = null;
		try {
			txn = this.env.beginTransaction(null, null);
			CursorConfig cc = new CursorConfig();
			cc.setReadCommitted(true);
			if (myCursor == null)
				myCursor = frontierDatabase.openCursor(txn, cc);
			DatabaseEntry foundKey = new DatabaseEntry();
			DatabaseEntry foundData = new DatabaseEntry();
			EntryBinding dataBinding = new SerialBinding(classCatalog, Page.class);
			// ʹ��cursor.getPrev�����������α��ȡ����
			if (myCursor.getFirst(foundKey, foundData, LockMode.DEFAULT) == OperationStatus.SUCCESS) {
				String theKey = new String(foundKey.getData(), "UTF-8");
				Page theData = (Page) dataBinding.entryToObject(foundData);
				resultList.add(theKey);
				// System.out.println("Key | Data : " + theKey + " | " + theData
				// + "");
				while (myCursor.getNext(foundKey, foundData, LockMode.DEFAULT) == OperationStatus.SUCCESS) {
					theKey = new String(foundKey.getData(), "UTF-8");
					theData = (Page) dataBinding.entryToObject(foundData);
					resultList.add(theKey);
					// System.out.println("Key | Data : " + theKey + " | " +
					// theData + "");
				}
			}
			myCursor.close();
			txn.commit();
			return resultList;
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			return null;
		} catch (Exception e) {
			System.out.println("getEveryItem���������쳣");

			txn.abort();
			if (myCursor != null) {
				myCursor.close();
			}
			return null;
		}
	}

	/*
	 * ����keyֵɾ�����ݿ��е�һ����¼
	 */
	public boolean deleteFromDatabase(String key) {
		boolean success = false;
		long sleepMillis = 0;
		for (int i = 0; i < 3; i++) {
			if (sleepMillis != 0) {
				try {
					Thread.sleep(sleepMillis);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				sleepMillis = 0;
			}
			Transaction txn = null;
			try {
				// 1��ʹ��cursor.getPrev�����������α��ȡ����
				TransactionConfig txConfig = new TransactionConfig();
				txConfig.setSerializableIsolation(true);
				txn = env.beginTransaction(null, txConfig);
				DatabaseEntry theKey;
				theKey = new DatabaseEntry(key.getBytes("UTF-8"));

				// 2��ɾ������ ���ύ
				OperationStatus res = frontierDatabase.delete(txn, theKey);
				txn.commit();
				if (res == OperationStatus.SUCCESS) {
					// System.out.println("�����ݿ�" + dbName + "��ɾ��:" + key);
					success = true;
					return success;
				} else if (res == OperationStatus.KEYEMPTY) {
					System.out.println("û�д����ݿ�" + dbName + "���ҵ�:" + key + "���޷�ɾ��");
				} else {
					System.out.println("ɾ������ʧ�ܣ�����" + res.toString());
				}
				return false;
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
				return false;
			} catch (LockConflictException lockConflict) {
				System.out.println("ɾ������ʧ�ܣ�����lockConflict�쳣");
				sleepMillis = 1000;

				continue;
			} finally {
				if (!success) {
					if (txn != null) {
						txn.abort();
					}
				}
			}
		}
		return false;
	}

	public void closeDB() {
		if (frontierDatabase != null) {
			frontierDatabase.close();
			classDb.close();
		}
		if (env != null) {
			env.close();
		}
	}

	/*
	 * �õ���1��
	 */
	public String getFirstItem() {
		Cursor myCursor = null;
		Transaction txn = null;
		String returnStr = null;
		;
		try {
			txn = this.env.beginTransaction(null, null);
			CursorConfig cc = new CursorConfig();
			cc.setReadCommitted(true);
			if (myCursor == null)
				myCursor = frontierDatabase.openCursor(txn, cc);
			DatabaseEntry foundKey = new DatabaseEntry();
			DatabaseEntry foundData = new DatabaseEntry();
			EntryBinding dataBinding = new SerialBinding(classCatalog, Page.class);
			// ʹ��cursor.getPrev�����������α��ȡ����
			if (myCursor.getFirst(foundKey, foundData, LockMode.DEFAULT) == OperationStatus.SUCCESS) {
				String theKey = new String(foundKey.getData(), "UTF-8");
				Page theData = (Page) dataBinding.entryToObject(foundData);
				returnStr = theKey;
			}
			myCursor.close();
			txn.commit();
			return returnStr;
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			return null;
		} catch (Exception e) {
			System.out.println("getFirstItem���������쳣");
			txn.abort();
			if (myCursor != null) {
				myCursor.close();
			}
			return null;
		}
	}

	/**
	 * �õ���k��Ԫ��Page
	 */
	public Page getKItem(int k) {
		Cursor myCursor = null;
		Transaction txn = null;
		Page theData = null;
		// String returnStr = null;
		try {
			txn = this.env.beginTransaction(null, null);
			CursorConfig cc = new CursorConfig();
			cc.setReadCommitted(true);
			if (myCursor == null)
				myCursor = frontierDatabase.openCursor(txn, cc);
			DatabaseEntry foundKey = new DatabaseEntry();
			DatabaseEntry foundData = new DatabaseEntry();
			EntryBinding dataBinding = new SerialBinding(classCatalog, Page.class);
			// ʹ��cursor.getXxxx�����������α��ȡ����
			int i = 1;
			if (myCursor.getFirst(foundKey, foundData, LockMode.DEFAULT) == OperationStatus.SUCCESS) {
				if (k == 1) {
					String theKey = new String(foundKey.getData(), "UTF-8");
					theData = (Page) dataBinding.entryToObject(foundData);
					// returnStr = theKey;
				}
				i++;
				while (myCursor.getNext(foundKey, foundData, LockMode.DEFAULT) == OperationStatus.SUCCESS && k > 1) {
					if (k == i) {
						String theKey = new String(foundKey.getData(), "UTF-8");
						theData = (Page) dataBinding.entryToObject(foundData);
						// returnStr = theKey;
					}
					i++;
				}

			}
			myCursor.close();
			txn.commit();
			return theData;
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			return null;
		} catch (Exception e) {
			System.out.println("getFirstItem���������쳣");
			txn.abort();
			if (myCursor != null) {
				myCursor.close();
			}
			return null;
		}
	}

	/**
	 * �õ�ĳ��Ԫ�ص���һ��Ԫ��page
	 */
	public Page getPagNextItem(Page pageToFind) {
		String key = null;
		if (pageToFind == null)
			return null;
		else
			key = pageToFind.getUrl();
		if (key == null)
			return null;
		Cursor myCursor = null;
		Transaction txn = null;
		Page theData = null;
		// String returnStr = null;
		try {
			txn = this.env.beginTransaction(null, null);
			CursorConfig cc = new CursorConfig();
			cc.setReadCommitted(true);
			if (myCursor == null)
				myCursor = frontierDatabase.openCursor(txn, cc);
			DatabaseEntry foundKey = new DatabaseEntry(key.getBytes("UTF-8"));
			DatabaseEntry foundData = new DatabaseEntry();
			EntryBinding dataBinding = new SerialBinding(classCatalog, Page.class);
			// ʹ��cursor.getXxxx�����������α��ȡ����
			if (myCursor.getSearchKey(foundKey, foundData, LockMode.DEFAULT) == OperationStatus.SUCCESS) {
				if(myCursor.getNext(foundKey, foundData, LockMode.DEFAULT) == OperationStatus.SUCCESS){
					String theKey = new String(foundKey.getData(), "UTF-8");
					theData = (Page) dataBinding.entryToObject(foundData);
				}
			}
			myCursor.close();
			txn.commit();
			return theData;
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			return null;
		} catch (Exception e) {
			System.out.println("getFirstItem���������쳣");
			txn.abort();
			if (myCursor != null) {
				myCursor.close();
			}
			return null;
		}
	}

}
