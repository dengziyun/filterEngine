package com.hctc.crawler.common;

import java.util.List;
import com.hctc.crawler.db.PageCRUD;

public class CommRef {
	//Ҫ���ʵĵ�һ��url
	public  String firstUrl ;
	public  List<String> inStrArray ;
	//visited����
	public  String dbVisitedLocation;
	//todo����
	public  String dbTodoLocation;
	public  PageCRUD dbTodoUtil;
	public  PageCRUD dbVisitedUtil;
	public String getFirstUrl() {
		return firstUrl;
	}
	public void setFirstUrl(String firstUrl) {
		this.firstUrl = firstUrl;
	}

	public List<String> getInStrArray() {
		return inStrArray;
	}
	public void setInStrArray(List<String> inStrArray) {
		this.inStrArray = inStrArray;
	}
	public String getDbVisitedLocation() {
		return dbVisitedLocation;
	}
	public void setDbVisitedLocation(String dbVisitedLocation) {
		this.dbVisitedLocation = dbVisitedLocation;
	}
	public String getDbTodoLocation() {
		return dbTodoLocation;
	}
	public void setDbTodoLocation(String dbTodoLocation) {
		this.dbTodoLocation = dbTodoLocation;
	}
	public PageCRUD getDbTodoUtil() {
		return dbTodoUtil;
	}
	public void setDbTodoUtil(PageCRUD dbTodoUtil) {
		this.dbTodoUtil = dbTodoUtil;
	}
	public PageCRUD getDbVisitedUtil() {
		return dbVisitedUtil;
	}
	public void setDbVisitedUtil(PageCRUD dbVisitedUtil) {
		this.dbVisitedUtil = dbVisitedUtil;
	}

	
}
