package com.hctc.crawler.common;

import java.util.Date;

import org.apache.http.Header;

public class BackCode {
	public void back1() {
		/*
		 * Header[] s = response.getAllHeaders(); for (int i = 0; i < s.length;
		 * i++) { Header hd = s[i];
		 * if(hd.getName().toLowerCase().equals("last-modified")){
		 * System.out.println(hd.getValue()); System.out.println(new
		 * Date(hd.getValue())); }else
		 * System.out.println(hd.getName()+"=="+hd.getValue());
		 * 
		 * if(hd.getName().toLowerCase().equals("content-length")){
		 * System.out.println(hd.getValue()); } }
		 */
	}
}
