package com.hctc.crawler.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Node;
import org.jsoup.nodes.TextNode;

import com.hctc.parse.filter.NodeClass;
import com.hctc.parse.filter.NodeTool;

public class CommUtil {
	/**
	 * �ж��Ƿ��ǺϷ���Url
	 * 
	 * @param pageUrl
	 * @return
	 */
	public static Pattern pattern = Pattern
			.compile("^([hH][tT]{2}[pP]://|[hH][tT]{2}[pP][sS]://)(([A-Za-z0-9-~]+).)+([A-Za-z0-9-~\\/])+$");

	public static boolean isUrl(String pageUrl) {
		if (pageUrl.contains("?") || pageUrl.contains("&"))
			return false;
		if (pageUrl.startsWith("http:") || pageUrl.startsWith("https:"))
			return true;
		else
			return false;
		// return pattern.matcher(pageUrl).matches();
	}

	/**
	 * �ж�Url�Ƿ�������ַ��������е�����һ��
	 * 
	 * @param link
	 * @param urlComArray
	 * @return
	 */
	public static boolean isContainsUrl(String link, List<String> urlComArray) {
		if (urlComArray == null || urlComArray.size() == 0)
			return false;
		if (link == null || link.isEmpty())
			return false;
		boolean flag = false;
		for (int i = 0; i < urlComArray.size(); i++) {
			if (link.indexOf(urlComArray.get(i)) != -1)
				flag = true;
		}
		return flag;
	}

	/**
	 * �ж����������Ƿ�ͬһ��
	 * 
	 * @param date1
	 * @param date2
	 * @return
	 */
	public static boolean isSameDate(Date date1, Date date2) {
		Calendar cal1 = Calendar.getInstance();
		cal1.setTime(date1);
		Calendar cal2 = Calendar.getInstance();
		cal2.setTime(date2);
		boolean isSameYear = cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR);
		boolean isSameMonth = isSameYear && cal1.get(Calendar.MONTH) == cal2.get(Calendar.MONTH);
		boolean isSameDate = isSameMonth && cal1.get(Calendar.DAY_OF_MONTH) == cal2.get(Calendar.DAY_OF_MONTH);
		return isSameDate;
	}

	/**
	 * д��־�ļ�
	 * 
	 * @throws IOException
	 * @throws UnsupportedEncodingException
	 */
	public static void writeLogALine(String str) throws UnsupportedEncodingException, IOException {
		SimpleDateFormat format = new SimpleDateFormat("yyMMdd");
		String dir = new String("e:/db/log/");
		File file = new File(dir);
		if (!file.exists())
			file.mkdir();
		file = new File(dir + format.format(new Date()) + ".log");
		if (!file.exists())
			file.createNewFile();
		FileOutputStream out = new FileOutputStream(file, true);
		format = new SimpleDateFormat("hhmmss");
		out.write((format.format(new Date()) + " " + str + "\r\n").getBytes("utf-8"));
		out.close();
	}

	/*
	 * public static String urlReplace(String urlStr){ urlStr =
	 * urlStr.replaceAll("&", "%26"); urlStr = urlStr.replaceAll(" ", "%20");
	 * urlStr = urlStr.replaceAll("|", "%124"); urlStr = urlStr.replaceAll("=",
	 * "%3D"); urlStr = urlStr.replaceAll("#", "%23"); urlStr =
	 * urlStr.replaceAll("/", "%2F"); urlStr = urlStr.replaceAll("+", "%2B");
	 * urlStr = urlStr.replaceAll("%", "%25"); return urlStr; }
	 */
	/**
	 * �ж���������Ʒ��Ϣ��ַ
	 * 
	 * @param url
	 * @return
	 */
	public static boolean isGoodsUrl(String url) {
		if (url == null || url.isEmpty())
			return false;
		String split1[] = StringUtils.split(url, "/");
		if (split1 == null || split1.length == 0)
			return false;
		int length1 = split1.length;
		String pageNameUrl = split1[length1 - 1];
		// System.out.println(pageNameUrl);
		String split2[] = StringUtils.split(pageNameUrl, ".");
		if (split2 == null || split2.length == 0 || split2.length != 2)
			return false;
		// System.out.println(split2[0]);
		if (StringUtils.isNumeric(split2[0])) {
			// ͳ�����ֵĸ���
			int digit = 0;
			for (int i = 0; i < split2[0].length(); i++) {
				char c = split2[0].charAt(i);
				if (c >= '0' && c <= '9')
					digit++;
			}
			if (digit > 6 && digit < 16 && split2[1] != null && "html".equals(split2[1]))
				return true;
			else
				return false;
		} else
			return false;
	}

	/**
	 * �õ�Ҫ���˵�����������
	 * 
	 * @return
	 */
	public static Node obtainJsoupNode() {
		File file = new File("e:/db/tree.html");
		Node node = null;
		try {
			Document doc = Jsoup.parse(file, "GBK");
			if (doc != null) {
				node = doc.childNode(0).childNode(1).childNode(0);
				removeTextTag(node);
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
		return node;
	}

	// �õ�nodeList1��ģ����ҳ�����ƶ�ֵ
	public static float obtainSim(ArrayList<NodeClass> nodeList1) {
		File file = new File("e:/db/model.html");
		ArrayList<NodeClass> nodeList2 =null;
		NodeTool tool = new NodeTool();
		try {
			Document doc2 = Jsoup.parse(file, "GBK");
			if (doc2 != null) {			
				nodeList2 = new ArrayList<NodeClass>();
				tool.obtainTreeList(nodeList2, doc2, 0);
				nodeList2 = delOtherTag(nodeList2);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		nodeList1=delOtherTag(nodeList1);
		if(nodeList1==null||nodeList2==null) return 0.0f;
		return tool.longestCommomSubSequence(nodeList1, nodeList2);		
	}

	// ɾ��text��ǩ
	public static void removeTextTag(Node node) {
		for (int i = 0; i < node.childNodeSize();) {
			Node child = node.childNode(i);
			if ("#text".equals(child.nodeName())) {
				child.remove();
			} else {
				removeTextTag(child);
				i++;
			}

		}
	}

	// ɾ��div��span�����������ǩ
	public static ArrayList<NodeClass> delOtherTag(ArrayList<NodeClass> nodeList) {
		if (nodeList == null)
			return null;
		ArrayList<NodeClass> tempArrayList = new ArrayList<NodeClass>();
		for (int i = 0; i < nodeList.size(); i++)
			if ((("div".equals(nodeList.get(i).getNode().nodeName())
					&& nodeList.get(i).getNode().attr("class") != null))
					|| (("span".equals(nodeList.get(i).getNode().nodeName())
							&& nodeList.get(i).getNode().attr("class") != null))) {
				tempArrayList.add(nodeList.get(i));
			}
		nodeList = tempArrayList;
		return nodeList;
	}
}
