package com.hctc.crawler.db;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.InvalidResultSetAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

import com.hctc.crawler.common.Page;

public class PageCRUD {
	public JdbcTemplate jdbcTemplate;
	public String tableName;

	// �����ݿ�������д������
	public void writeBatchUpdate(ArrayList<Page> list) {
		if(list==null) return;
		jdbcTemplate.batchUpdate(
				"insert into " + tableName + "(pageUrl,pageContent,updateDate,dataLength) values(?,?,?,?)",
				new BatchPreparedStatementSetter() {
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						ps.setString(1, list.get(i).getUrl());
						if (list.get(i).getPageContent() != null)
							ps.setString(2, list.get(i).getPageContent());
						else
							ps.setString(2, null);
						ps.setDate(3, new java.sql.Date(new java.util.Date().getTime()));
						if (list.get(i).getPageContent() != null && list.get(i).getPageContent().length() != 0)
							ps.setInt(4, list.get(i).getPageContent().length());
						else
							ps.setInt(4, 0);
					}

					public int getBatchSize() {
						return list.size();
					}
				});

	}

	// �����ݿ����д����
	public boolean writeToDatabase(String key, Page value, boolean isOverwrite) {
		if (key == null)
			return false;
		if (value != null && value.getPageContent() != null && (!value.getPageContent().isEmpty())) {
			// if (this.readFromDatabase(key) == null) {
			String sql = "insert into " + tableName + "(pageUrl,pageContent,updateDate,dataLength) values(?,?,?,?)";
			// System.out.println(sql);
			try {
				jdbcTemplate.update(sql, key, value.getPageContent(), new Date(), value.getPageContent().length());
			} catch (InvalidResultSetAccessException e) {
				// throw new RuntimeException(e);
			} catch (DataAccessException e) {
				// throw new RuntimeException(e);
			}
			// }
		} else {
			// if (this.readFromDatabase(key) == null) {
			String sql = "insert into " + tableName + "(pageUrl) values(?)";
			// System.out.println(sql);
			try {
				jdbcTemplate.update(sql, key);
			} catch (InvalidResultSetAccessException e) {
				// throw new RuntimeException(e);
			} catch (DataAccessException e) {
				// throw new RuntimeException(e);
			}
			// }
		}

		return true;
	}

	/*
	 * �����ݿ��ж������� ����key ����value
	 */
	public Page readFromDatabase(String key) {
		if (key == null)
			return null;
		String sql = "select * from " + tableName + " where pageUrl=?";
		List rows = jdbcTemplate.queryForList(sql, key);
		if (rows == null || rows.size() == 0)
			return null;
		Iterator it = rows.iterator();
		Page page = null;
		while (it.hasNext()) {
			Map map = (Map) it.next();
			page = new Page();
			page.setUrl(key);
			if (map.get("pageContent") != null)
				page.setPageContent((String) map.get("pageContent"));
			if (map.get("updateDate") != null)
				page.setUpdateDate((Date) map.get("updateDate"));
			if (map.get("dataLength") != null)
				page.setDataLength((int) map.get("dataLength"));
			break;
		}
		return page;
	}

	/*
	 * �������ݿ��е����м�¼������list
	 */
	public ArrayList<String> getEveryItem() {
		String sql = "select pageUrl from " + tableName;
		List rows = jdbcTemplate.queryForList(sql);
		if (rows == null || rows.size() == 0)
			return null;
		Iterator it = rows.iterator();
		ArrayList<String> pageArray = new ArrayList<String>();
		while (it.hasNext()) {
			Map map = (Map) it.next();
			pageArray.add((String) map.get("pageUrl"));
		}
		return pageArray;
	}

	/*
	 * ����keyֵɾ�����ݿ��е�һ����¼
	 */
	public boolean deleteFromDatabase(String key) {
		if (key == null)
			return false;
		String sql = "delete from " + tableName + " where pageUrl=?";
		jdbcTemplate.update(sql, key);
		return true;
	}

	/*
	 * �õ���1��
	 */
	public String getFirstItem() {
		String sql = "select top 1 pageUrl from " + tableName;
		List rows = jdbcTemplate.queryForList(sql);
		if (rows == null || rows.size() == 0)
			return null;
		Iterator it = rows.iterator();
		String url = null;
		while (it.hasNext()) {
			Map map = (Map) it.next();
			url = (String) map.get("pageUrl");
			break;
		}
		return url;
	}

	/**
	 * �õ���k*1000��PageԪ��
	 */
	public ArrayList<Page> getKMItems(int k) {
		if (k == 0)
			return null;
		List rows = null;
		if (k == 1) {
			String sql = "select top 500 * from " + tableName + " order by pageId asc";
			rows = jdbcTemplate.queryForList(sql);
		} else {
			String sql = "select top 500 * from " + tableName + " where pageId not in (" + "select top "
					+ (k - 1) * 500 + " pageId from " + tableName + " order by pageId asc ) order by pageId asc";
			rows = jdbcTemplate.queryForList(sql);
		}
		if (rows == null || rows.size() == 0)
			return null;
		Iterator it = rows.iterator();
		ArrayList<Page> arrayPages = new ArrayList<Page>();
		while (it.hasNext()) {
			Map map = (Map) it.next();
			Page page = new Page();
			page.setUrl((String) map.get("pageUrl"));
			if (map.get("pageContent") != null)
				page.setPageContent((String) map.get("pageContent"));
			if (map.get("updateDate") != null)
				page.setUpdateDate((Date) map.get("updateDate"));
			if (map.get("dataLength") != null)
				page.setDataLength((int) map.get("dataLength"));
			arrayPages.add(page);
		}
		return arrayPages;
	}

	/**
	 * �õ���k��Ԫ��Page
	 */
	public Page getKItem(int k) {
		if (k == 0)
			return null;
		List rows = null;
		if (k == 1) {
			String sql = "select top 1 * from " + tableName;
			rows = jdbcTemplate.queryForList(sql);
		} else {
			String sql = "select top 1 * from " + tableName + " where pageId not in ( select top " + (k - 1)
					+ " pageId from " + tableName + " order by pageId asc ) order by pageId asc";
			rows = jdbcTemplate.queryForList(sql);
		}
		if (rows == null || rows.size() == 0)
			return null;
		Iterator it = rows.iterator();
		Page page = null;
		while (it.hasNext()) {
			Map map = (Map) it.next();
			page = new Page();
			page.setUrl((String) map.get("pageUrl"));
			if (map.get("pageContent") != null)
				page.setPageContent((String) map.get("pageContent"));
			if (map.get("updateDate") != null)
				page.setUpdateDate((Date) map.get("updateDate"));
			if (map.get("dataLength") != null)
				page.setDataLength((int) map.get("dataLength"));
			break;
		}
		return page;
	}

	/**
	 * �õ�ĳ��Ԫ�ص���һ��Ԫ��page
	 */
	public Page getPagNextItem(Page pageToFind) {
		if (pageToFind == null || pageToFind.getUrl() == null)
			return null;
		String sql = "select top 1 * from " + tableName + " where pageUrl=?";
		List rows = jdbcTemplate.queryForList(sql, pageToFind.getUrl());
		if (rows == null || rows.size() == 0)
			return null;
		Iterator it = rows.iterator();
		int pageId = 0;
		while (it.hasNext()) {
			Map map = (Map) it.next();
			pageId = ((BigDecimal) map.get("pageId")).intValue();
			break;
		}
		sql = "select top 1 * from " + tableName + " where pageId>?";
		rows = jdbcTemplate.queryForList(sql, pageId);
		if (rows == null || rows.size() == 0)
			return null;
		it = rows.iterator();
		Page page = null;
		while (it.hasNext()) {
			Map map = (Map) it.next();
			page = new Page();
			page.setUrl((String) map.get("pageUrl"));
			if (map.get("pageContent") != null)
				page.setPageContent((String) map.get("pageContent"));
			if (map.get("updateDate") != null)
				page.setUpdateDate((Date) map.get("updateDate"));
			if (map.get("dataLength") != null)
				page.setDataLength((int) map.get("dataLength"));
			break;
		}
		return page;
	}

	/**
	 * �õ���¼����*
	 * 
	 * @return
	 */
	public int count() {
		String sql = "select count(*) from " + tableName;
		int count = jdbcTemplate.queryForObject(sql, Integer.class);
		return count;
	}

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

}
