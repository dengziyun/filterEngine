package com.hctc.crawler.page;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import com.hctc.crawler.common.CommUtil;

public class PageUtil {
	public  List<String> inStrArray ;
	/**
	 * ����ҳ�����н��������е���ҳ��ַ����
	 * 
	 * @param pageContent
	 * @return
	 */
	public  ArrayList<String> obtainUrlArray(String pageContent,String pageUrl) {
		
		if (pageContent == null || pageContent.isEmpty())
			return null;
		Document doc = Jsoup.parse(pageContent);
		Elements links = doc.getElementsByTag("a");
		if (links == null || links.size() == 0)
			return null;
		ArrayList<String> linkArray = new ArrayList<String>();
		String prefix=new String();
		if(pageUrl.startsWith("https:")) prefix="https:";
		if(pageUrl.startsWith("http:")) prefix="http:";
		for (Element link : links) {
			String linkHref = link.attr("href");
			/*try {
				linkHref=URLEncoder.encode(linkHref, "UTF-8");
				System.out.println(linkHref);
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}*/
			if (linkHref.startsWith("//")) {
				linkHref = prefix + linkHref;
				if (!linkHref.isEmpty() && CommUtil.isContainsUrl(linkHref, inStrArray) && CommUtil.isUrl(linkHref))
					linkArray.add(linkHref);
			} else {
				linkHref = link.absUrl("href");
				if (!linkHref.isEmpty() && CommUtil.isContainsUrl(linkHref, inStrArray)){
					if(linkHref.startsWith("//")||linkHref.startsWith("www.")||linkHref.startsWith("jd.")) linkHref = prefix + linkHref;					
					if(CommUtil.isUrl(linkHref)) linkArray.add(linkHref);
				}
			}
		}
		return linkArray;
	}

	/**
	 * �ж�ҳ���Ƿ�Ҫ��������
	 */
	public static boolean isToDown(String url, Date urlDate, Long urlLength) {
		if (url == null || url.isEmpty())
			return false;

		return false;
	}

	public List<String> getInStrArray() {
		return inStrArray;
	}

	public void setInStrArray(List<String> inStrArray) {
		this.inStrArray = inStrArray;
	}


}
