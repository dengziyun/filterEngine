package com.hctc.crawler.page;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import com.hctc.crawler.common.CommRef;
import com.hctc.crawler.common.CommUtil;
import com.hctc.crawler.common.Page;

public class DownPage {
	// Ҫ���ص�ҳ���ַ
	public String pageUrl;
	// ��������
	public CommRef commRef;
	//ҳ���������
	public PageUtil pageUtil;

	public String downPage() throws UnsupportedEncodingException, IOException {
		//pageUrl=URLDecoder.decode(pageUrl, "UTF-8");
		// ��ַ��Ϊ��
		if (pageUrl == null || pageUrl.isEmpty())
			return null;
		// ��ַ�Ϸ�
		if (!CommUtil.isUrl(pageUrl))
			return null;
		// ����Ѿ����ʹ�
		if (haveVisited(pageUrl))
			return null;
		/*if (!isUsed(pageUrl))
			return null;*/
		// ������ҳ����
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpGet httpget = null;
		try{
			//pageUrl=URLEncoder.encode(pageUrl, "UTF-8");
			URL url = new URL(pageUrl);
			URI uri = new URI(url.getProtocol(), url.getHost(), url.getPath(), url.getQuery(), null);
			httpget = new HttpGet(uri);
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
		
		RequestConfig requestConfig = RequestConfig.custom()  
		        .setConnectTimeout(10000).setConnectionRequestTimeout(10000)  
		        .setSocketTimeout(10000).build();  
		httpget.setConfig(requestConfig);  
		try {
			HttpResponse response = httpclient.execute(httpget);
			HttpEntity entity = response.getEntity();
			if (entity != null) {
				String pagecontentstr = EntityUtils.toString(entity, "utf-8");
				EntityUtils.consume(entity);// �ر�������
				// ����Page���󲢱��浽visited
				Page page = new Page();
				page.setUrl(pageUrl);
				page.setUpdateDate(new Date());
				page.setDataLength(pagecontentstr.length());
				page.setPageContent(pagecontentstr);
				//System.out.println(pageUrl);
				commRef.dbVisitedUtil.writeToDatabase(pageUrl, page, true);
				// �������µ���ҳ�б�����todo
				/*
				ArrayList<String> pageUrlArray = pageUtil.obtainUrlArray(pagecontentstr,pageUrl);
				//System.out.println(pageUrlArray.size());
				if (pageUrlArray != null && pageUrlArray.size() > 0) {
					for (String pageUrlArrayElement : pageUrlArray) {
						//System.out.println(haveVisited(pageUrlArrayElement)+pageUrlArrayElement);
						if (!haveVisited(pageUrlArrayElement)) {	
							Page pageTodo = new Page();
							pageTodo.setUrl(pageUrlArrayElement);
							commRef.dbTodoUtil.writeToDatabase(pageUrlArrayElement, pageTodo, true);
						}
					}
				}
				*/
				return pagecontentstr;
			} else
				return null;
		} catch (ClientProtocolException e) {
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}

	}

	// �ж��Ƿ��Ѿ����ʹ�
	public boolean haveVisited(String pageUrlStr) throws UnsupportedEncodingException, IOException {
		//String logStr="judgeVisited*";
		//long a = new Date().getTime();
		if (pageUrlStr == null || pageUrlStr.isEmpty())
			return true;
		//CommUtil.writeLogALine(logStr);
		/*if (!CommUtil.isUrl(pageUrlStr))//�������һ��url
			return true;*/
		if(!(pageUrlStr.startsWith("http:")||pageUrlStr.startsWith("https:"))) return true;
		Page page = commRef.dbVisitedUtil.readFromDatabase(pageUrlStr);
		if (page == null){
			return false;// �Ҳ���˵����û���ʹ�
		}else {
			return true;
			/*if (CommUtil.isSameDate(new Date(), page.getUpdateDate()))
				return true;
			else
				return false;// ����ͬһ��˵����û���ʹ�
				*/
		}
	}

	// �ж������Ƿ����
	public boolean isUsed(String pageUrlStr) {
		URL url;
		try {
			//System.out.println(">>>>>>����start:"+pageUrlStr);
			int status = 404;
			url = new URL(pageUrlStr);
			HttpURLConnection oc = (HttpURLConnection) url.openConnection();
			oc.setUseCaches(false);
			oc.setConnectTimeout(2000); //�������ӳ�ʱʱ��
			oc.setReadTimeout(10000);//�����ݳ�ʱʱ��
			status = oc.getResponseCode();// ����״̬
			//System.out.println(">>>>>>����ok:"+pageUrlStr+">>>>"+status);
			if (status == 200)
				return true;
			else
				return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public String getPageUrl() {
		return pageUrl;
	}

	public void setPageUrl(String pageUrl) {
		this.pageUrl = pageUrl;
	}

	public CommRef getCommRef() {
		return commRef;
	}

	public void setCommRef(CommRef commRef) {
		this.commRef = commRef;
	}

	public PageUtil getPageUtil() {
		return pageUtil;
	}

	public void setPageUtil(PageUtil pageUtil) {
		this.pageUtil = pageUtil;
	}

}
