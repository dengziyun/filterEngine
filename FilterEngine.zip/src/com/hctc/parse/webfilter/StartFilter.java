package com.hctc.parse.webfilter;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class StartFilter {

	public static void main(String[] args) {
		ApplicationContext contextFilter = new ClassPathXmlApplicationContext("com/hctc/parse/webfilter/BeanConfig.xml");
		FilterThreadExecutor filter= contextFilter.getBean("filter", FilterThreadExecutor.class);
		filter.start(contextFilter);


	}

}
