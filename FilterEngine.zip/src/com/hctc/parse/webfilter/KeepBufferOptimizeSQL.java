package com.hctc.parse.webfilter;

import java.util.ArrayList;

import com.hctc.crawler.common.Page;
import com.hctc.crawler.db.PageCRUD;

public class KeepBufferOptimizeSQL implements Runnable {
	public static ArrayList<ArrayList> arrayListList = new ArrayList<ArrayList>();// ������
	public PageCRUD dbVisitedUtil;
	public static int popNums = 0;// �����뻺������ҳ��ĸ���

	@Override
	public void run() {// ����������̵߳Ķ�����д�뻺����
		ArrayList<Page> page500 = new ArrayList<Page>();
		int k = 1;
		while (true) {
			// ȷ��������10��ArrayListԪ�أ��൱�ڳ�ʼ��
			for (int i = 0; i < 5; i++) {
				if (arrayListList == null)
					arrayListList = new ArrayList<ArrayList>();
				if (arrayListList.size() < 5)
					arrayListList.add(new ArrayList<Page>());
			}

			// �ҳ�Ϊ�յ�ArrayList
			boolean haveEmptyArray = false;
			ArrayList<Page> arrayList=this.findEmptyArray(arrayListList);
			if(arrayList!=null&&arrayList.isEmpty()){
				haveEmptyArray=true;
			}
			
			// ���û�пտ�
			if (!haveEmptyArray)
				continue;
			// ======����пտ�======
			// ���page500Ϊ��,���µõ�һ���µ�1000��Page
			if (page500 == null || page500.isEmpty()) {
				// ��¼���ݿ����ʱ��
				page500=null;
				long startTime = System.currentTimeMillis();
				page500 = dbVisitedUtil.getKMItems(k);
				// System.out.println(k);
				k++;
				// ��¼���ݿ����ʱ��
				long endTime = System.currentTimeMillis();
				long timems = endTime - startTime;
				TagFilterRun.selectDealTime += timems;
			}
			if (page500 == null || page500.isEmpty())
				break;// �Ҳ��������ˣ�˵��ȫ��������

			// һ��ȡ100�����뻺����
			int size = page500.size();
			if (size >= 100) {
				for (int i = 0; i < 100; i++) {
					Page page = page500.get(i);
					if (arrayList == null){
						arrayList=new ArrayList<Page>();
						if(arrayListList.size() < 5) arrayListList.add(arrayList);
					}
					arrayList.add(page);
					popNums++;
				}
			} else {
				for (int i = 0; i < size; i++) {
					Page page = page500.get(i);
					if (arrayList == null){
						arrayList=new ArrayList<Page>();
						if(arrayListList.size() < 5) arrayListList.add(arrayList);
					}
					arrayList.add(page);
					popNums++;
				}
			}

			// ɾ��ǰ100��Ԫ��
			size = page500.size();
			if (size >= 100)
				for (int i = 0; i < 100; i++)
					page500.remove(0);
			else
				for (int i = 0; i < size; i++)
					page500.remove(0);
		}
	}

	public ArrayList<Page> findEmptyArray(ArrayList<ArrayList> arrayListList) {
		if (arrayListList == null || arrayListList.isEmpty())
			return null;
		for (int i = 0; i < arrayListList.size(); i++) {
			ArrayList arrayList = arrayListList.get(i);
			if (arrayList == null) {
				arrayList = new ArrayList<Page>();
				arrayListList.set(i, arrayList);
				return arrayList;
			}else{
				if (arrayList.isEmpty()) return arrayList;
			}
		}
		return null;
	}

	public static ArrayList<ArrayList> getArrayListList() {
		return arrayListList;
	}

	public static void setArrayListList(ArrayList<ArrayList> arrayListList) {
		KeepBufferOptimizeSQL.arrayListList = arrayListList;
	}

	public PageCRUD getDbVisitedUtil() {
		return dbVisitedUtil;
	}

	public void setDbVisitedUtil(PageCRUD dbVisitedUtil) {
		this.dbVisitedUtil = dbVisitedUtil;
	}

	public static int getPopNums() {
		return popNums;
	}

	public static void setPopNums(int popNums) {
		KeepBufferOptimizeSQL.popNums = popNums;
	}

}
