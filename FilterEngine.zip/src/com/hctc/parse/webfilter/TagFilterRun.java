package com.hctc.parse.webfilter;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Node;

import com.hctc.crawler.common.CommUtil;
import com.hctc.crawler.common.Page;
import com.hctc.crawler.db.PageCRUD;
import com.hctc.parse.filter.TagFilter;

public class TagFilterRun implements Runnable {
	// public DBUtil dbVisitedUtil;
	public TagFilter tagFilter;
	public PageCRUD dbToFilterUtil;// �ѱ�ǩ���˵���ҳ
	public static int dealNums = 0;// ���˵���ҳ����
	public static Long preTimems = System.currentTimeMillis();// ��һ�μ�¼����ʱ��
	public static Long dataDealTime = 0l;// ÿ1000�ۻ������ݴ�����ʱ�䣬insert
	public static Long selectDealTime = 0l;// ÿ1000�ۻ������ݴ�����ʱ�䣬select

	@Override
	public void run() {// �ӻ�������ȡ����ҳ�����б�ǩ�Ĺ��ˣ���д���µĶ���
		// int i=0;
		while (true) {
			ArrayList<ArrayList> buffer = KeepBufferOptimizeSQL.getArrayListList();// �õ�������
			if (buffer == null || buffer.size() == 0)
				continue;
			// �õ���һ��ArrayList<Page>
			ArrayList<Page> bufferQueue = buffer.get(0);
			if (bufferQueue == null || bufferQueue.isEmpty())// ���Ϊ��
				continue;

			// ������100��
			for (int i = 0; i < bufferQueue.size(); i++) {
				Page page = bufferQueue.get(i);
				if (page == null || page.getPageContent() == null || page.getPageContent().length() == 0)
					continue;
				Document doc = Jsoup.parse(page.getPageContent());
				if (doc != null) {// ��ǩ����
					Node nodeDoc = (Node) doc;
					tagFilter.removeComments(nodeDoc);
					page.setPageContent(nodeDoc.toString());
				}

			}
			// ��¼���ݿ����ʱ��
			long startTime = System.currentTimeMillis();
			// ִ�����ݿ����
			dbToFilterUtil.writeBatchUpdate(bufferQueue);
			// ��¼���ݿ����ʱ��
			long endTime = System.currentTimeMillis();
			long timems = endTime - startTime;
			dataDealTime += timems;
			dealNums += bufferQueue.size();

			// ɾ������������ִ���������
			if (buffer != null && bufferQueue != null && buffer.size() > 0)
				buffer.remove(0);

			// ��¼��־
			if (dealNums % 1000 == 0) {
				endTime = System.currentTimeMillis();
				timems = endTime - preTimems;
				preTimems = endTime;
				try {
					CommUtil.writeLogALine("    " + dealNums + "   timems:" + timems + "   " + "s:"
							+ TimeUnit.MILLISECONDS.toSeconds(timems) + "    " + "insertTime(s):" + dataDealTime
							+ "    " + "selectTime(s):" + selectDealTime);
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
				System.out.println(dealNums + "   timems:" + timems + "   " + "s:"
						+ TimeUnit.MILLISECONDS.toSeconds(timems) + "    " + "dataDealTime(s):" + dataDealTime + "    "
						+ "selectTime(s):" + selectDealTime);
				dataDealTime = 0l;
				selectDealTime = 0l;
			}
		}
	}

	public static int getDealNums() {
		return dealNums;
	}

	public static void setDealNums(int dealNums) {
		TagFilterRun.dealNums = dealNums;
	}

	public TagFilter getTagFilter() {
		return tagFilter;
	}

	public void setTagFilter(TagFilter tagFilter) {
		this.tagFilter = tagFilter;
	}

	public PageCRUD getDbToFilterUtil() {
		return dbToFilterUtil;
	}

	public void setDbToFilterUtil(PageCRUD dbToFilterUtil) {
		this.dbToFilterUtil = dbToFilterUtil;
	}

	public static Long getPreTimems() {
		return preTimems;
	}

	public static void setPreTimems(Long preTimems) {
		TagFilterRun.preTimems = preTimems;
	}

	public static Long getDataDealTime() {
		return dataDealTime;
	}

	public static void setDataDealTime(Long dataDealTime) {
		TagFilterRun.dataDealTime = dataDealTime;
	}

	public static Long getSelectDealTime() {
		return selectDealTime;
	}

	public static void setSelectDealTime(Long selectDealTime) {
		TagFilterRun.selectDealTime = selectDealTime;
	}

}
