package com.hctc.parse.webfilter.intelligence;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import com.hctc.crawler.common.PropertiesOp;
import com.word.FnlpOp;

public class DndM {
	// �ʵ�Ƶ��ͳ��Map������һ��ͳ��һ�ξͿ����ˣ���ͬһ����ҳ�У�����Ҫ��ȥ��
	public static HashMap<String, Integer> wordMap = new HashMap<String, Integer>();
	// ��ϸ��Ϣҳ�ʵ�DndֵMap
	public static HashMap<String, Double> dndDetailMap = new HashMap<String, Double>();
	// �ʵķ���ϸ��Ϣҳ��dndMap
	public static HashMap<String, Double> dndNonDetailMap = new HashMap<String, Double>();
	// ���ڷ���ϸ��Ϣҳ���Map
	public static HashMap<String, Integer> idfCountMap = new HashMap<String, Integer>();
	// ��ϸ��Ϣҳ����
	public static int totalDetailCount;
	// ����ϸ��Ϣҳ������
	public static int totalNonDetailCount;
	public FnlpOp fnlpOp;// �ִ���
	// �ʵ�dndֵ��Map
	public static HashMap<String, Double> dndMap = new HashMap<String, Double>();

	// �����µ���ҳ(��ϸ��Ϣ)����ҳ�����Ѿ�ɾ���˶���ı�ǩ��&nbsp;
	public void addDetailPage(String pageContent) {
		totalDetailCount++;
		if (pageContent == null || pageContent.isEmpty())
			return;
		String[] result = fnlpOp.obtainWords(pageContent);
		// ȥ�ش���������>=2
		ArrayList<String> list = new ArrayList<String>();
		for (int i = 0; i < result.length; i++) {
			if (result[i].length() < 2)
				continue;
			if (list == null || list.isEmpty()) {
				list.add(result[i]);
				continue;
			}
			boolean containsFlag = false;
			for (int j = 0; j < list.size(); j++) {
				String listStr = list.get(j);
				if (listStr.equals(result[i])) {
					containsFlag = true;
					break;
				}
			}
			if (!containsFlag)
				list.add(result[i]);
		}
		// �����������Ƶ��
		for (int i = 0; i < list.size(); i++) {
			String wordAndProp = fnlpOp.obtainWordsAndProps(list.get(i));
			String[] wordAndPropArray = wordAndProp.split("/");
			if (wordAndPropArray == null || wordAndPropArray.length != 2)
				continue;
			if (!("����".equals(wordAndPropArray[1]) || "����".equals(wordAndPropArray[1])
					|| "����".equals(wordAndPropArray[1]) || "���ݴ�".equals(wordAndPropArray[1])))
				continue;
			if (!wordMap.containsKey(list.get(i))) {// ���������
				wordMap.put(list.get(i), 1);
			} else {// ����Ѵ���
				int value = wordMap.get(list.get(i));
				wordMap.put(list.get(i), value + 1);
			}
		}
	}

	// ����dndDetailֵ
	public void updatedndDetailMap() {
		Iterator<String> it = wordMap.keySet().iterator();
		//System.out.print("\n nondetail��ҳ�У�\n");
		while (it.hasNext()) {
			String key = it.next();
			int value = wordMap.get(key);			
			//if (1.0d * value / totalDetailCount > 0.7d) System.out.print(key+1.0d * value / totalDetailCount+"  ");
			if (1.0d * value / totalDetailCount > 0.01d){
				double putValue=0.0d;
				//if(key.contains("��")||key.contains("����")||key.contains("����"))  putValue=2.0d * value / totalDetailCount;
				//else putValue=1.0d * value / totalDetailCount;
				putValue=1.0d * value / totalDetailCount;
				dndDetailMap.put(key, putValue);
				
			}
				
		}
		//System.out.print("\n=====================================nondetail\n");
	}

	// �����µ���ҳ(����ϸ��Ϣ)����ҳ�����Ѿ�ɾ���˶���ı�ǩ��&nbsp;
	public void addNonDetailPage(String pageContent) {
		totalNonDetailCount++;
		if (pageContent == null || pageContent.isEmpty())
			return;
		String[] result = fnlpOp.obtainWords(pageContent);
		// ȥ�ش���������>=2
		ArrayList<String> list = new ArrayList<String>();
		for (int i = 0; i < result.length; i++) {
			if (result[i].length() < 2)
				continue;
			if (list == null || list.isEmpty()) {
				list.add(result[i]);
				continue;
			}
			boolean containsFlag = false;
			for (int j = 0; j < list.size(); j++) {
				String listStr = list.get(j);
				if (listStr.equals(result[i])) {
					containsFlag = true;
					break;
				}
			}
			if (!containsFlag)
				list.add(result[i]);
		}
		for (int i = 0; i < list.size(); i++) {
			String wordAndProp = fnlpOp.obtainWordsAndProps(list.get(i));
			String[] wordAndPropArray = wordAndProp.split("/");
			if (wordAndPropArray == null || wordAndPropArray.length != 2)
				continue;
			if (!("����".equals(wordAndPropArray[1]) || "����".equals(wordAndPropArray[1])
					|| "����".equals(wordAndPropArray[1]) || "���ݴ�".equals(wordAndPropArray[1])))
				continue;
			if (idfCountMap.containsKey(list.get(i))) {// ����
				int value = idfCountMap.get(list.get(i));
				idfCountMap.put(list.get(i), value + 1);
			} else {
				idfCountMap.put(list.get(i), 1);
			}
		}
	}

	// ����dndNonDetailֵ
	public void updateDndNonDetailMap() {
		Iterator<String> it = idfCountMap.keySet().iterator();
		//System.out.print("\ndetail��ҳ�У�\n");
		while (it.hasNext()) {
			String key = it.next();
			int value = idfCountMap.get(key);
			//if(1.0d - 1.0d * value / totalNonDetailCount > 0.7d) System.out.print(key+(1.0d - 1.0d * value / totalNonDetailCount)+"  ");
			if (1.0d - 1.0d * value / totalNonDetailCount > 0.05d)
				dndNonDetailMap.put(key, 1.0d - 1.0d * value / totalNonDetailCount);
		}
		//System.out.print("\n==========================detail\n");
	}

	// �õ�dnd������󷵻�list
	public List<Map.Entry<String, Double>> updateDndMap() {
		Iterator<String> it = dndDetailMap.keySet().iterator();
		while (it.hasNext()) {
			String key = it.next();
			Double dndValue = 0.0d;
			if (dndNonDetailMap.containsKey(key)) {
				dndValue = dndDetailMap.get(key) * dndNonDetailMap.get(key);
				dndMap.put(key, dndValue);
				// dndValue = dndDetailMap.get(key) * 100;
			}
			// else
			// dndValue = dndDetailMap.get(key);

		}
		// ����
		List<Map.Entry<String, Double>> list = new ArrayList<Map.Entry<String, Double>>(dndMap.entrySet());
		Collections.sort(list, new Comparator<Map.Entry<String, Double>>() {
			// ��������
			public int compare(Entry<String, Double> o1, Entry<String, Double> o2) {
				return o2.getValue().compareTo(o1.getValue());
			}

		});
		return list;
	}

	// �õ�dnd��������
	public void updateDndMapNoSequence() {
		Iterator<String> it = dndDetailMap.keySet().iterator();
		while (it.hasNext()) {
			String key = it.next();
			Double dndValue = 0.0d;
			if (dndNonDetailMap.containsKey(key))
				dndValue = dndDetailMap.get(key) * dndNonDetailMap.get(key) * 100;
			else
				dndValue = dndDetailMap.get(key) * 100;
			dndMap.put(key, dndValue);
		}
	}

	// ��dnd����󷵻�list
	public List<Map.Entry<String, Double>> sortDndMap() {
		// ����
		List<Map.Entry<String, Double>> list = new ArrayList<Map.Entry<String, Double>>(dndMap.entrySet());
		Collections.sort(list, new Comparator<Map.Entry<String, Double>>() {
			// ��������
			public int compare(Entry<String, Double> o1, Entry<String, Double> o2) {
				return o2.getValue().compareTo(o1.getValue());
			}

		});
		return list;
	}
	
	// ��dnd����󷵻�list
	public List<Map.Entry<String, Double>> sortDndDetailMap() {
		// ����
		List<Map.Entry<String, Double>> list = new ArrayList<Map.Entry<String, Double>>(dndDetailMap.entrySet());
		Collections.sort(list, new Comparator<Map.Entry<String, Double>>() {
			// ��������
			public int compare(Entry<String, Double> o1, Entry<String, Double> o2) {
				return o2.getValue().compareTo(o1.getValue());
			}

		});
		return list;
	}

	// ȡProperties�ļ��������Чֵ
	public double obtainPerformance(String pageContent, String fileName) {
		if (pageContent == null || pageContent.isEmpty())
			return 0.0d;
		// �ִʴ���
		String[] result = fnlpOp.obtainWords(pageContent);
		// ȥ�ظ�����
		List<String> list = new ArrayList<String>();
		for (int i = 0; i < result.length; i++) {
			String key = result[i];
			if (list.isEmpty()) {
				list.add(key);
				continue;
			}
			boolean containsFlag = false;
			for (int j = 0; j < list.size(); j++) {
				String listStr = list.get(j);
				if (listStr.equals(result[i])) {
					containsFlag = true;
					break;
				}
			}
			if (!containsFlag)
				list.add(result[i]);
		}

		// ���㼨Чֵ
		Double performance = 0.0d;
		PropertiesOp op = new PropertiesOp();
		String path = Class.class.getClass().getResource("/").getPath();
		path += fileName;
		double sum = 0.0d;
		Properties pps = op.GetAllProperties(path);
		for (Iterator<Object> iterator = pps.keySet().iterator(); iterator.hasNext();) {
			String key = (String) iterator.next();
			Double value = new Double((String) pps.get(key));
			sum += value;
		}
		for (int i = 0; i < list.size(); i++) {
			String key = list.get(i);
			String valueStr = op.GetValueByKey(path, key);
			if (valueStr == null)
				continue;
			Double value = new Double(valueStr);
			performance += value / sum;
		}
		return performance;
	}

	// ȡProperties�ļ��������Чֵ(����ʽ)
	public double obtainPerformanceByP(String pageContent) {
		if (pageContent == null || pageContent.isEmpty())
			return 0.0d;
		// �ִʴ���
		String[] result = fnlpOp.obtainWords(pageContent);
		// ȥ�ظ�����
		List<String> list = new ArrayList<String>();
		for (int i = 0; i < result.length; i++) {
			String key = result[i];
			if (list.isEmpty()) {
				list.add(key);
				continue;
			}
			boolean containsFlag = false;
			for (int j = 0; j < list.size(); j++) {
				String listStr = list.get(j);
				if (listStr.equals(result[i])) {
					containsFlag = true;
					break;
				}
			}
			if (!containsFlag)
				list.add(result[i]);
		}

		// �õ�Test.properties������
		Double performance = 0.0d;
		PropertiesOp op = new PropertiesOp();
		String path = Class.class.getClass().getResource("/").getPath();
		path += "Test.properties";
		Properties ps = op.GetAllProperties(path);
		Map<String, Double> map = new HashMap<String, Double>();
		Set<Entry<Object, Object>> set = ps.entrySet();
		Iterator<Entry<Object, Object>> it = set.iterator();
		while (it.hasNext()) {
			Entry<Object, Object> ele = it.next();
			String key = ele.getKey().toString();
			String valueStr = ele.getValue().toString();
			Double value = new Double(valueStr);
			map.put(key, value);
		}

		// ����
		List<Map.Entry<String, Double>> listPs = new ArrayList<Map.Entry<String, Double>>(map.entrySet());
		Collections.sort(listPs, new Comparator<Map.Entry<String, Double>>() {
			// ��������
			public int compare(Entry<String, Double> o1, Entry<String, Double> o2) {
				return o2.getValue().compareTo(o1.getValue());
			}

		});
		// �ټ��㼨Чֵ
		for (int i = 0; i < listPs.size(); i++) {
			Map.Entry<String, Double> ele = listPs.get(i);
			String key = ele.getKey();
			Double value = ele.getValue();
			// �����key��list��
			boolean containsFlag = false;
			for (int j = 0; j < list.size(); j++) {
				String listStr = list.get(j);
				if (listStr.equals(key)) {
					containsFlag = true;
					break;
				}
			}
			if (containsFlag) {
				System.out.println(key + "++++" + value + "+++++" + performance);
				performance += (1 - performance) * value;
			}
		}
		return performance;
	}

	public static HashMap<String, Integer> getWordMap() {
		return wordMap;
	}

	public static void setWordMap(HashMap<String, Integer> wordMap) {
		DndM.wordMap = wordMap;
	}

	public static HashMap<String, Double> getDndDetailMap() {
		return dndDetailMap;
	}

	public static void setDndDetailMap(HashMap<String, Double> dndDetailMap) {
		DndM.dndDetailMap = dndDetailMap;
	}

	public static HashMap<String, Double> getDndNonDetailMap() {
		return dndNonDetailMap;
	}

	public static void setDndNonDetailMap(HashMap<String, Double> dndNonDetailMap) {
		DndM.dndNonDetailMap = dndNonDetailMap;
	}

	public static HashMap<String, Integer> getIdfCountMap() {
		return idfCountMap;
	}

	public static void setIdfCountMap(HashMap<String, Integer> idfCountMap) {
		DndM.idfCountMap = idfCountMap;
	}

	public static int getTotalDetailCount() {
		return totalDetailCount;
	}

	public static void setTotalDetailCount(int totalDetailCount) {
		DndM.totalDetailCount = totalDetailCount;
	}

	public static int getTotalNonDetailCount() {
		return totalNonDetailCount;
	}

	public static void setTotalNonDetailCount(int totalNonDetailCount) {
		DndM.totalNonDetailCount = totalNonDetailCount;
	}

	public FnlpOp getFnlpOp() {
		return fnlpOp;
	}

	public void setFnlpOp(FnlpOp fnlpOp) {
		this.fnlpOp = fnlpOp;
	}

	public static HashMap<String, Double> getDndMap() {
		return dndMap;
	}

	public static void setDndMap(HashMap<String, Double> dndMap) {
		DndM.dndMap = dndMap;
	}

}
