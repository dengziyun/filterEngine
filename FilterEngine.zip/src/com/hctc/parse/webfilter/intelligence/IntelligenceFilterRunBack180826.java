package com.hctc.parse.webfilter.intelligence;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Node;

import com.hctc.crawler.common.CommUtil;
import com.hctc.crawler.common.Page;
import com.hctc.crawler.common.PropertiesOp;
import com.hctc.crawler.db.PageCRUD;
import com.hctc.parse.filter.NodeClass;
import com.hctc.parse.filter.NodeTool;
import com.hctc.parse.filter.NumLinksTool;
import com.hctc.parse.webfilter.KeepBufferPageFilterSQL;

public class IntelligenceFilterRunBack180826 implements Runnable {
	public PageCRUD dbFeatureFilterUtil;
	public NodeTool nodeTool;
	public NumLinksTool linksTool;
	public boolean containStringFilterFlag;// �����ַ������˱�־
	public boolean containsTagFilterFlag;// ������ǩ���˱�־
	public boolean linksRateFilterFlag;// ���ӱȹ��˱�־
	public boolean containChildTreeFilterFlag;// �����������˱�־
	public boolean simRateFilterFlag;// ���ƶȹ��˱�־
	public boolean tfIdfFilterFlag;// TFIDF����
	public boolean dndFilterFlag;// dnd����

	public static int dealNums = 0;// ���˵���ҳ����
	public static int dealAfterNums = 0;// ���˺����ҳ����
	public static Long preTimems = System.currentTimeMillis();// ��һ�μ�¼����ʱ��
	public static Long dataDealTime = 0l;// ÿ1000�ۻ������ݴ�����ʱ�䣬insert
	public static Long selectDealTime = 0l;// ÿ1000�ۻ������ݴ�����ʱ�䣬select
	public static int allUrlCount = 0;// Ŀǰ����������Ʒ��Ϣ��ҳ����
	public static int filteredUrlCount = 0;// Ŀǰ���˺�����Ʒ��Ϣ��ҳ����
	public static int filteredCount = 0;// ���˺�õ�����Ϊ����Ʒ��Ϣ��ҳ�ĸ���

	public TfIdf tfIdf;
	public DndM dndM;

	@Override
	public void run() {// ��������ֵ������ҳ

		boolean flagFinish = false;// ���ƽ��̱�־������isFinishFlagΪtrueʱ����һ��
		
		int errorCount=0;
		int trueCount=0;
		
		int nondetailCount = 0;
		while (true) {
			ArrayList<ArrayList> buffer = KeepBufferPageFilterSQL.getArrayListList();// �õ�������
			if (KeepBufferPageFilterSQL.isFinishFlag()) {// ȫ��������
				System.out.println("Finished!");
				if (flagFinish)
					break;
				else
					flagFinish = true;
			}
			if (buffer == null || buffer.size() == 0)
				continue;
			// �õ���һ��ArrayList<Page>
			ArrayList<Page> bufferQueue = buffer.get(0);
			if (bufferQueue == null || bufferQueue.isEmpty())// ���Ϊ��
				continue;
			if (bufferQueue.size() < 100 && !flagFinish)// �ߴ�û��100�Ҳ������һ��
				continue;
			// ������100��
			// �����һ��Ϊ100���Ѿ�������
			dealNums += bufferQueue.size();
			int j = 0;// ��¼ɾ���Ĵ���
			for (int i = 0; i < bufferQueue.size(); i++) {
				Page page = bufferQueue.get(i);
				if (page == null || page.getPageContent() == null || page.getPageContent().length() == 0) {
					bufferQueue.remove(i);
					i--;// ����
					j++;
					continue;
				}
				Document doc = Jsoup.parse(page.getPageContent());
				if (doc == null) {
					bufferQueue.remove(i);
					j++;
					i--;// ����
					continue;
				}
				// ��¼����
				boolean isGoodsFlag = CommUtil.isGoodsUrl(page.getUrl());
				if (isGoodsFlag)
					allUrlCount++;

				// ִ��TFIDF��������
				if (dndFilterFlag) {
					int countTrain = 10000;// ѵ����������
					boolean isDetailFlag = false;//��ʼֵ
					boolean isPerformance = false;
					boolean isDetailTest = true;
					boolean isNonDetailTest = false;

					if (isPerformance) {
						Node nodeDoc = (Node) doc;
						StringBuffer bufferStr = new StringBuffer();
						bufferStr = nodeTool.obtainAllText(nodeDoc, bufferStr);
						String testFileNameDetail = new String("DetailTest.properties");
						String testFileNameNonDetail = new String("NonDetailTest.properties");
						Double performanceDetail = dndM.obtainPerformance(bufferStr.toString(), testFileNameDetail);
						//Double performanceNonDetail = dndM.obtainPerformance(bufferStr.toString(),
						//		testFileNameNonDetail);
						
						String path = Class.class.getClass().getResource("/").getPath();
						path = path + "Performance.properties";
						PropertiesOp op = new PropertiesOp();
						DecimalFormat df = new DecimalFormat("######0.000000");
						
						/*
						if (isGoodsFlag && filteredCount < countTrain) {
							try {
								op.WriteProperties(path, "ok,"+(filteredCount+1), df.format(performanceDetail*100));
								//System.out.println("====ok"+(filteredCount+1)+"="+df.format(performance*100));
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
						if (!isGoodsFlag && nondetailCount < countTrain) {
							try {
								op.WriteProperties(path, "non,"+nondetailCount, df.format(performanceDetail*100));
								//System.out.println("====non,"+nondetailCount+"="+df.format(performance*100));
							} catch (IOException e) {
								e.printStackTrace();
							}
							nondetailCount++;
						}				
						
						if (nondetailCount >= countTrain && filteredCount >= countTrain) {
							System.out.println("====ok");
							flagFinish = true;
							return;
						}
						isDetailFlag=isGoodsFlag;
						*/
						
						if(performanceDetail>=0.7) isDetailFlag = true;
						else isDetailFlag=false;
						
						
						
					}

					if (isDetailTest || isNonDetailTest) {
						Node nodeDoc = (Node) doc;
						StringBuffer bufferStr = new StringBuffer();
						bufferStr = nodeTool.obtainAllText(nodeDoc, bufferStr);
						if (isGoodsFlag && filteredCount < countTrain) {
							//if (filteredCount % 200 == 0 || filteredCount == countTrain - 1)
							//	System.out.println("====filteredCount1=" + filteredCount);
							if(isDetailTest) dndM.addDetailPage(bufferStr.toString());
							if (isNonDetailTest)
								dndM.addNonDetailPage(bufferStr.toString());
						}

						if (!isGoodsFlag && nondetailCount < countTrain) {
							if(isDetailTest)
								dndM.addNonDetailPage(bufferStr.toString());
							if(isNonDetailTest)
								dndM.addDetailPage(bufferStr.toString());
							nondetailCount++;
							//if (nondetailCount % 200 == 0)
							//	System.out.println("====filteredCount2=" + nondetailCount);
						}

						if (nondetailCount >= countTrain && filteredCount >= countTrain) {
							flagFinish = true;
							dndM.updatedndDetailMap();
							dndM.updateDndNonDetailMap();
							List<Map.Entry<String, Double>> list = dndM.updateDndMap();

							// �������properties
							String path = Class.class.getClass().getResource("/").getPath();
							if(isDetailTest) path += "DetailTest.properties";
							if(isNonDetailTest) path += "NonDetailTest.properties";
							PropertiesOp op = new PropertiesOp();
							System.out.print("\n"+path + "====" + list.size());
							double percent = 0.0d;
							// int count=0;
							for (Map.Entry<String, Double> mapping : list) {
								if (mapping.getValue() > 1e-4) {
									try {
										op.WriteProperties(path, mapping.getKey(),
												(new BigDecimal(mapping.getValue())).toString());
										NumberFormat nf = NumberFormat.getInstance(); // ������ʽ����nf
										nf.setMaximumFractionDigits(4); // ��ֵ2��ʾ����2λС��
										String s = nf.format(mapping.getValue()); // ����ת����Ľ����String���͵�
										System.out.print("\n"+mapping.getKey() + "====" + s);
									} catch (IOException e) {
										e.printStackTrace();
									}
									// count++;
									// if(count>100) break;
									// percent += mapping.getValue();
								}
							}
							System.out.print("\n====ok\n");
							return;
						}
						isDetailFlag = isGoodsFlag;
					}


					if (isDetailFlag) {// ��Ϊ����ϸҳ
						if (isGoodsFlag)
							filteredUrlCount++;
						filteredCount++;
					} else {// ������ϸҳ
						bufferQueue.remove(i);
						j++;
						i--;// ����
					}
				}

			}
			if (j != 100) {// ����ɾ����100�Σ���������ȫ������ϸ��Ϣ��ҳ
				// ��¼���ݿ����ʱ��
				long startTime = System.currentTimeMillis();
				// ִ�����ݿ����
				// dbFeatureFilterUtil.writeBatchUpdate(bufferQueue);
				// ��¼���ݿ����ʱ��
				long endTime = System.currentTimeMillis();
				long timems = endTime - startTime;
				dataDealTime += timems;
				dealAfterNums += bufferQueue.size();

				// ɾ������������ִ���������
				if (buffer != null && bufferQueue != null && bufferQueue.size() >= 0)
					buffer.remove(0);
			}
			// ��¼��־
			if (dealNums % 1000 == 0) {
				long endTime = System.currentTimeMillis();
				long timems = endTime - preTimems;
				preTimems = endTime;
				try {
					CommUtil.writeLogALine("   dealNums:" + dealNums + "   dealAfterNums:" + dealAfterNums
							+ "    allUrlCount:" + allUrlCount + "   filteredCount:" + filteredCount
							+ "    filteredUrlCount:" + filteredUrlCount + "   timems:" + timems + "   " + "s:"
							+ TimeUnit.MILLISECONDS.toSeconds(timems) + "    " + "insertTime(s):" + dataDealTime
							+ "    " + "selectTime(s):" + selectDealTime);
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
				System.out.print("\n"+dealNums + "   timems:" + timems + "   " + "s:"
						+ TimeUnit.MILLISECONDS.toSeconds(timems) + "    " + "dataDealTime(s):" + dataDealTime + "    "
						+ "selectTime(s):" + selectDealTime);
				dataDealTime = 0l;
				selectDealTime = 0l;
			}
		}

	}

	public PageCRUD getDbFeatureFilterUtil() {
		return dbFeatureFilterUtil;
	}

	public void setDbFeatureFilterUtil(PageCRUD dbFeatureFilterUtil) {
		this.dbFeatureFilterUtil = dbFeatureFilterUtil;
	}

	public NodeTool getNodeTool() {
		return nodeTool;
	}

	public void setNodeTool(NodeTool nodeTool) {
		this.nodeTool = nodeTool;
	}

	public NumLinksTool getLinksTool() {
		return linksTool;
	}

	public void setLinksTool(NumLinksTool linksTool) {
		this.linksTool = linksTool;
	}

	public boolean isContainStringFilterFlag() {
		return containStringFilterFlag;
	}

	public void setContainStringFilterFlag(boolean containStringFilterFlag) {
		this.containStringFilterFlag = containStringFilterFlag;
	}

	public static int getDealNums() {
		return dealNums;
	}

	public static void setDealNums(int dealNums) {
		IntelligenceFilterRun.dealNums = dealNums;
	}

	public static int getDealAfterNums() {
		return dealAfterNums;
	}

	public static void setDealAfterNums(int dealAfterNums) {
		IntelligenceFilterRun.dealAfterNums = dealAfterNums;
	}

	public static Long getPreTimems() {
		return preTimems;
	}

	public static void setPreTimems(Long preTimems) {
		IntelligenceFilterRun.preTimems = preTimems;
	}

	public static Long getDataDealTime() {
		return dataDealTime;
	}

	public static void setDataDealTime(Long dataDealTime) {
		IntelligenceFilterRun.dataDealTime = dataDealTime;
	}

	public static Long getSelectDealTime() {
		return selectDealTime;
	}

	public static void setSelectDealTime(Long selectDealTime) {
		IntelligenceFilterRun.selectDealTime = selectDealTime;
	}

	public static int getAllUrlCount() {
		return allUrlCount;
	}

	public static void setAllUrlCount(int allUrlCount) {
		IntelligenceFilterRun.allUrlCount = allUrlCount;
	}

	public static int getFilteredUrlCount() {
		return filteredUrlCount;
	}

	public static void setFilteredUrlCount(int filteredUrlCount) {
		IntelligenceFilterRun.filteredUrlCount = filteredUrlCount;
	}

	public static int getFilteredCount() {
		return filteredCount;
	}

	public static void setFilteredCount(int filteredCount) {
		IntelligenceFilterRun.filteredCount = filteredCount;
	}

	public boolean isContainsTagFilterFlag() {
		return containsTagFilterFlag;
	}

	public void setContainsTagFilterFlag(boolean containsTagFilterFlag) {
		this.containsTagFilterFlag = containsTagFilterFlag;
	}

	public boolean isLinksRateFilterFlag() {
		return linksRateFilterFlag;
	}

	public void setLinksRateFilterFlag(boolean linksRateFilterFlag) {
		this.linksRateFilterFlag = linksRateFilterFlag;
	}

	public boolean isContainChildTreeFilterFlag() {
		return containChildTreeFilterFlag;
	}

	public void setContainChildTreeFilterFlag(boolean containChildTreeFilterFlag) {
		this.containChildTreeFilterFlag = containChildTreeFilterFlag;
	}

	public boolean isSimRateFilterFlag() {
		return simRateFilterFlag;
	}

	public void setSimRateFilterFlag(boolean simRateFilterFlag) {
		this.simRateFilterFlag = simRateFilterFlag;
	}

	public boolean isTfIdfFilterFlag() {
		return tfIdfFilterFlag;
	}

	public void setTfIdfFilterFlag(boolean tfIdfFilterFlag) {
		this.tfIdfFilterFlag = tfIdfFilterFlag;
	}

	public TfIdf getTfIdf() {
		return tfIdf;
	}

	public void setTfIdf(TfIdf tfIdf) {
		this.tfIdf = tfIdf;
	}

	public boolean isDndFilterFlag() {
		return dndFilterFlag;
	}

	public void setDndFilterFlag(boolean dndFilterFlag) {
		this.dndFilterFlag = dndFilterFlag;
	}

	public DndM getDndM() {
		return dndM;
	}

	public void setDndM(DndM dndM) {
		this.dndM = dndM;
	}

}
