package com.hctc.parse.webfilter.intelligence;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.hctc.crawler.common.PropertiesOp;
import com.word.FnlpOp;

public class TfIdf {
	// �ʵ�Ƶ��ͳ��Map
	public static HashMap<String, Integer> wordMap = new HashMap<String, Integer>();
	// �ʵ�TFֵMap
	public static HashMap<String, Float> tfMap = new HashMap<String, Float>();
	// �ʵ�IDFֵMap
	public static HashMap<String, Double> idfMap = new HashMap<String, Double>();
	// ���ڷ���ϸ��Ϣҳ���Map
	public static HashMap<String, Integer> idfCountMap = new HashMap<String, Integer>();
	// ��Ƶ��
	public static int totalCount;
	// ����ϸ��Ϣҳ������
	public static int totalNonDetailCount;
	public FnlpOp fnlpOp;// �ִ���
	// �ʵ�TFIDFֵ��Map
	public static HashMap<String, Double> tfIdfMap = new HashMap<String, Double>();

	// �����µ���ҳ(��ϸ��Ϣ)����ҳ�����Ѿ�ɾ���˶���ı�ǩ��&nbsp;
	public void addDetailPage(String pageContent) {
		if (pageContent == null || pageContent.isEmpty())
			return;
		String[] result = fnlpOp.obtainWords(pageContent);
		totalCount += result.length;
		// �����������Ƶ��
		for (int i = 0; i < result.length; i++) {
			if(result[i].length()<2) continue;
			String wordAndProp = fnlpOp.obtainWordsAndProps(result[i]);
			String[] wordAndPropArray = wordAndProp.split("/");
			//System.out.println((wordAndPropArray == null || wordAndPropArray.length != 2));
			if (wordAndPropArray == null || wordAndPropArray.length != 2)
				continue;
			if (!("����".equals(wordAndPropArray[1]) || "����".equals(wordAndPropArray[1]) || "����".equals(wordAndPropArray[1])
					|| "���ݴ�".equals(wordAndPropArray[1])))
				continue;
			if (!wordMap.containsKey(result[i])) {// ���������
				wordMap.put(result[i], 1);
			} else {// ����Ѵ���
				int value = wordMap.get(result[i]);
				wordMap.put(result[i], value + 1);
			}
		}
	}

	// ����TFֵ
	public void updateTfMap() {
		Iterator<String> it = wordMap.keySet().iterator();
		while (it.hasNext()) {
			String key = it.next();
			int value = wordMap.get(key);
			tfMap.put(key, 1.0f * value / totalCount);
		}
	}

	// �����µ���ҳ(����ϸ��Ϣ)����ҳ�����Ѿ�ɾ���˶���ı�ǩ��&nbsp;
	public void addNonDetailPage(String pageContent) {
		totalNonDetailCount++;
		if (pageContent == null || pageContent.isEmpty())
			return;
		String[] result = fnlpOp.obtainWords(pageContent);
		for (int i = 0; i < result.length; i++) {
			if(result[i].length()<2) continue;
			// if (wordMap.containsKey(result[i])) {//���wordMap���зִʳ�����Ԫ��
			String wordAndProp = fnlpOp.obtainWordsAndProps(result[i]);
			String[] wordAndPropArray = wordAndProp.split("/");
			if (wordAndPropArray == null || wordAndPropArray.length != 2)
				continue;
			if (!("����".equals(wordAndPropArray[1]) || "����".equals(wordAndPropArray[1]) || "����".equals(wordAndPropArray[1])
					|| "���ݴ�".equals(wordAndPropArray[1])))
				continue;
			if (idfCountMap.containsKey(result[i])) {// ����
				int value = idfCountMap.get(result[i]);
				idfCountMap.put(result[i], value + 1);
			} else {
				idfCountMap.put(result[i], 1);
			}
			// }
		}
	}

	// ����IDFֵ
	public void updateIdfMap() {
		Iterator<String> it = idfCountMap.keySet().iterator();
		while (it.hasNext()) {
			String key = it.next();
			int value = idfCountMap.get(key);
			idfMap.put(key, Math.log10(1.0d * value / totalNonDetailCount));
		}
	}

	// �õ�tfidf������󷵻�list
	public List<Map.Entry<String, Double>> updateTfIdfMap() {
		Iterator<String> it = tfMap.keySet().iterator();
		while (it.hasNext()) {
			String key = it.next();
			Double tfIdfValue = 0.0d;
			if (idfMap.containsKey(key))
				tfIdfValue = tfMap.get(key) * idfMap.get(key)*100;
			else
				tfIdfValue = tfMap.get(key) * 3.0d*100;
			tfIdfMap.put(key, tfIdfValue);
		}
		// ����
		List<Map.Entry<String, Double>> list = new ArrayList<Map.Entry<String, Double>>(tfIdfMap.entrySet());
		Collections.sort(list, new Comparator<Map.Entry<String, Double>>() {
			// ��������
			public int compare(Entry<String, Double> o1, Entry<String, Double> o2) {
				return o2.getValue().compareTo(o1.getValue());
			}

		});
		return list;
	}

	// �õ�tfidf��������
	public void updateTfIdfMapNoSequence() {
		Iterator<String> it = tfMap.keySet().iterator();
		while (it.hasNext()) {
			String key = it.next();
			Double tfIdfValue = 0.0d;
			if (idfMap.containsKey(key))
				tfIdfValue = tfMap.get(key) * idfMap.get(key)*100;
			else
				tfIdfValue = tfMap.get(key) * 3.0d*100;
			tfIdfMap.put(key, tfIdfValue);
		}
	}
	// ��tfidf����󷵻�list
	public List<Map.Entry<String, Double>> sortTfIdfMap() {
		// ����
		List<Map.Entry<String, Double>> list = new ArrayList<Map.Entry<String, Double>>(tfIdfMap.entrySet());
		Collections.sort(list, new Comparator<Map.Entry<String, Double>>() {
			// ��������
			public int compare(Entry<String, Double> o1, Entry<String, Double> o2) {
				return o2.getValue().compareTo(o1.getValue());
			}

		});
		return list;
	}	
	
	//ȡProperties�ļ��������Чֵ
	public double obtainPerformance(String pageContent){
		if(pageContent==null||pageContent.isEmpty()) return 0.0d;
		//�ִʴ���
		String[] result = fnlpOp.obtainWords(pageContent);
		//ȥ�ظ�����
		List<String> list=new ArrayList<String>();
		for(int i=0;i<result.length;i++){
			String key=result[i];
			/*
			if(list.isEmpty()){
				list.add(key);
				continue;
			}
			if(!list.contains(result[i])) list.add(key);
			*/
			list.add(key);
		}
		
		//���㼨Чֵ
		Double performance=0.0d;
		PropertiesOp op=new PropertiesOp();
		String path = Class.class.getClass().getResource("/").getPath();
		path += "Test.properties";
		for(int i=0;i<list.size();i++){
			String key=list.get(i);
			String valueStr=op.GetValueByKey(path, key);
			if(valueStr==null) continue;
			Double value=new Double(valueStr);
			performance+=value;
		}
		return performance;
	}
	
	public static HashMap<String, Integer> getWordMap() {
		return wordMap;
	}

	public static void setWordMap(HashMap<String, Integer> wordMap) {
		TfIdf.wordMap = wordMap;
	}

	public FnlpOp getFnlpOp() {
		return fnlpOp;
	}

	public void setFnlpOp(FnlpOp fnlpOp) {
		this.fnlpOp = fnlpOp;
	}

	public static HashMap<String, Float> getTfMap() {
		return tfMap;
	}

	public static void setTfMap(HashMap<String, Float> tfMap) {
		TfIdf.tfMap = tfMap;
	}

	public static int getTotalCount() {
		return totalCount;
	}

	public static void setTotalCount(int totalCount) {
		TfIdf.totalCount = totalCount;
	}

	public static int getTotalNonDetailCount() {
		return totalNonDetailCount;
	}

	public static void setTotalNonDetailCount(int totalNonDetailCount) {
		TfIdf.totalNonDetailCount = totalNonDetailCount;
	}

	public static HashMap<String, Double> getIdfMap() {
		return idfMap;
	}

	public static void setIdfMap(HashMap<String, Double> idfMap) {
		TfIdf.idfMap = idfMap;
	}

	public static HashMap<String, Integer> getIdfCountMap() {
		return idfCountMap;
	}

	public static void setIdfCountMap(HashMap<String, Integer> idfCountMap) {
		TfIdf.idfCountMap = idfCountMap;
	}

	public static HashMap<String, Double> getTfIdfMap() {
		return tfIdfMap;
	}

	public static void setTfIdfMap(HashMap<String, Double> tfIdfMap) {
		TfIdf.tfIdfMap = tfIdfMap;
	}

}
