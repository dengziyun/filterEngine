package com.hctc.parse.webfilter.intelligence;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

import com.hctc.crawler.common.PropertiesOp;
import com.word.FnlpOp;

public class PageData {
	public static String[] wordsArray = null;// �����б�
	public static float[][] wordsCountArray = null;// ҳ�浥��Ƶ������
	
	
	// ����filePath�������ļ���·��������pageCount������ҳ����
	public PageData(String filePath, int pageCount) {
		if (filePath == null || filePath.length() == 0)
			return;
		PropertiesOp op = new PropertiesOp();
		String path = Class.class.getClass().getResource("/").getPath();
		String propFilePath = path + filePath;
		Properties pps = op.GetAllProperties(propFilePath);
		// ������Źؼ������ݵ��ļ�
		String logFilePath = new String("words.txt");
		logFilePath = path + logFilePath;
		File file = new File(logFilePath);
		String content = new String();// Ҫд���ļ�������
		int i = 1;
		wordsArray = new String[pps.size()];
		for (Iterator<Object> iterator = pps.keySet().iterator(); iterator.hasNext();) {
			String key = (String) iterator.next();
			if (i == 1)
				content += "no,isDetail," + key;
			else
				content = content + "," + key;
			wordsArray[i - 1] = new String(key);
			i++;
		}
		wirteALine(file, content);
		wordsCountArray = new float[pageCount * 2][pps.size()+2];
	}

	// ����ϸ��Ϣҳ��ִʺ��ۼ�����,����pageContentΪҳ�����ݣ�����isDetail��ʾ�Ƿ���ϸҳ������pageNo��ʾ�ڶ��ٸ�ҳ��
	public String WordsCount(int pageCount,String pageContent, boolean isDetail, int pageNo) {
		if (pageContent == null || pageContent.isEmpty())
			return null;
		FnlpOp fnlpOp = new FnlpOp();
		String[] result = fnlpOp.obtainWords(pageContent);
		ArrayList<String> list = new ArrayList<String>();
		for (int i = 0; i < result.length; i++) {
			if (result[i].length() < 2)
				continue;
			list.add(result[i]);
		}

		int[] pageWordsCount = new int[wordsArray.length];
		for (int i = 0; i < pageWordsCount.length; i++)
			pageWordsCount[i] = 0;
		for (int i = 0; i < list.size(); i++) {
			String key = list.get(i);
			for (int j = 0; j < wordsArray.length; j++) {
				if (wordsArray[j].equals(key)) {
					pageWordsCount[j] += 1;
				}
			}
		}
		String content = new String(pageNo + "," + isDetail);
		
		if(isDetail){
			wordsCountArray[pageCount+pageNo-1][0]=pageNo;
			wordsCountArray[pageCount+pageNo-1][1]=1;
		}else{
			wordsCountArray[pageNo-1][0]=pageNo;
			wordsCountArray[pageNo-1][1]=0;
		}
		for (int i = 0; i < pageWordsCount.length; i++) {
			if(isDetail)
				wordsCountArray[pageCount+pageNo-1][i+2] = pageWordsCount[i];
			else
				wordsCountArray[pageNo-1][i+2] = pageWordsCount[i];
			content = content + "," + pageWordsCount[i];
		}

		String logFilePath = new String("words.txt");
		String path = Class.class.getClass().getResource("/").getPath();
		logFilePath = path + logFilePath;
		File file = new File(logFilePath);
		//System.out.println(content);
		wirteALine(file, content);
		return content;
	}

	// ���ļ���д��һ��
	public void wirteALine(File file, String content) {
		if (file == null || content == null | content.isEmpty())
			return;
		if (!file.exists())
			try {
				file.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		FileOutputStream out;
		try {
			out = new FileOutputStream(file, true);
			out.write((content + "\r\n").getBytes("utf-8"));
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void checkDataBug(){
		int countEro=0;
		for(int i=0;i<wordsCountArray.length;i++){
			if(Math.abs(wordsCountArray[i][1]-1.0f) <= 1e-6){//�������ϸҳ
				boolean allIsEro=true;
				for(int k=2;k<wordsCountArray[i].length;k++){
					if(Math.abs(wordsCountArray[i][k]-0.0f) >= 1e-6){//�в�Ϊ0��
						allIsEro=false;
						break;
					}
				}
				if(allIsEro) countEro++;
			}
		}
		System.out.println("��"+countEro+"����ϸ��ϢҳȫΪ0");
		
		countEro=0;
		for(int i=0;i<wordsCountArray.length;i++){
			if(Math.abs(wordsCountArray[i][1]-0.0f) <= 1e-6){//����Ƿ���ϸҳ
				boolean allIsEro=true;
				for(int k=2;k<wordsCountArray[i].length;k++){
					if(Math.abs(wordsCountArray[i][k]-0.0f) >= 1e-6){//�в�Ϊ0��
						allIsEro=false;
						break;
					}
				}
				if(allIsEro) countEro++;
			}
		}
		System.out.println("��"+countEro+"������ϸ��ϢҳȫΪ0");	
		
		countEro=0;
		for(int i=0;i<wordsCountArray.length;i++){//����
			if(Math.abs(wordsCountArray[i][1]-0.0f) <= 1e-6){//����Ƿ���ϸҳ����������û�����ͻ����ϸҳ
				int counti=0;
				for(int j=0;j<wordsCountArray.length;j++){//����
					if(Math.abs(wordsCountArray[j][1]-1.0f) <= 1e-6){//�������ϸҳ
						boolean isEqual=true;
						for(int k=2;k<wordsCountArray[j].length;k++){
							if(Math.abs(wordsCountArray[j][k]-wordsCountArray[i][k]) >= 1e-6){//�����
								isEqual=false;
								break;
							}
						}
						if(isEqual){//�г�ͻ
							counti++;
						}
					}
					if(j==wordsCountArray.length-1&&counti>0){
						//System.out.println(i+"-->"+counti);
					}
				}
				if(counti>0) countEro++;
			}
		}
		System.out.println("��"+countEro+"������ϸ��Ϣҳ�г�ͻ");	
		
	}
	
}
