package com.hctc.parse.webfilter;

import org.springframework.context.ApplicationContext;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;

import com.hctc.parse.webfilter.intelligence.IntelligenceFilterRun;
import com.hctc.parse.webfilter.intelligence.IntelligenceFilterTfIdfRun;

public class FilterThreadExecutor {
	public TaskExecutor executor;
	public int threadCount;

	// �첽��������߳�
	public void executeTasks(ApplicationContext contextFilter) {
		// ����ά����ǩ���˻������߳�
		KeepBufferPageFilterSQL keepBuffer = contextFilter.getBean("keepBuffer", KeepBufferPageFilterSQL.class);
		executor.execute(keepBuffer);
		// ������ǩ�����߳�
		/*
		 * TagFilterRun tagFilterTask = contextFilter.getBean("tagFilterTask",
		 * TagFilterRun.class); executor.execute(tagFilterTask);
		 */
		
		// �������������߳�
		FeatureFilterRun featureFilterTask = contextFilter.getBean("featureFilterTask", FeatureFilterRun.class);
		executor.execute(featureFilterTask);
		
	}

	public void start(ApplicationContext contextFilter) {
		FilterThreadExecutor ee = new FilterThreadExecutor();
		ee.setExecutor(new SimpleAsyncTaskExecutor());
		ee.executeTasks(contextFilter);
	}

	public TaskExecutor getExecutor() {
		return executor;
	}

	public void setExecutor(TaskExecutor executor) {
		this.executor = executor;
	}

	public int getThreadCount() {
		return threadCount;
	}

	public void setThreadCount(int threadCount) {
		this.threadCount = threadCount;
	}
}
