package com.hctc.parse.webfilter;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Node;

import com.hctc.crawler.common.CommUtil;
import com.hctc.crawler.common.Page;
import com.hctc.crawler.db.PageCRUD;
import com.hctc.parse.filter.NodeClass;
import com.hctc.parse.filter.NodeTool;
import com.hctc.parse.filter.NumLinksTool;

public class KeepBufferPageFilterSQL implements Runnable {
	public static ArrayList<ArrayList> arrayListList = new ArrayList<ArrayList>();// ������
	public PageCRUD dbToFilterUtil;
	public static int popNums = 0;// �����뻺������ҳ��ĸ���
	public static boolean finishFlag = false;// ����������?

	@Override
	public void run() {// ����������̵߳Ķ�����д�뻺����

		ArrayList<Page> page500 = new ArrayList<Page>();
		int k = 1;
		while (true) { // ȷ��������5��ArrayListԪ�أ��൱�ڳ�ʼ��
			for (int i = 0; i < 5; i++) {
				if (arrayListList == null)
					arrayListList = new ArrayList<ArrayList>();
				if (arrayListList.size() < 5)
					arrayListList.add(new ArrayList<Page>());
			}

			// �ҳ�Ϊ�յ�ArrayList
			boolean haveEmptyArray = false;
			ArrayList<Page> arrayList = this.findEmptyArray(arrayListList);
			if (arrayList != null && arrayList.isEmpty()) {
				haveEmptyArray = true;
			}

			// ���û�пտ�
			if (!haveEmptyArray)
				continue;
			// ======����пտ�====== //
			// ���page500Ϊ��,���µõ�һ���µ�500��Page
			if (page500 == null || page500.isEmpty()) { // ��¼���ݿ����ʱ��
				page500 = null;
				long startTime = System.currentTimeMillis();
				page500 = dbToFilterUtil.getKMItems(k);
				// System.out.println(k); 
				k++; 
				// ��¼���ݿ����ʱ��
				long endTime = System.currentTimeMillis();
				long timems = endTime - startTime;
				FeatureFilterRun.selectDealTime += timems;
			}
			if (page500 == null || page500.isEmpty())
				break;// �Ҳ��������ˣ�˵��ȫ��������

			// һ��ȡ100�����뻺����
			int size = page500.size();
			if (size >= 100) {
				for (int i = 0; i < 100; i++) {
					Page page = page500.get(i);
					if (arrayList == null) {
						arrayList = new ArrayList<Page>();
						if (arrayListList.size() < 5)
							arrayListList.add(arrayList);
						//else System.out.println("======");
					}
					arrayList.add(page);
					popNums++;
				}
			} else {
				for (int i = 0; i < size; i++) {
					Page page = page500.get(i);
					if (arrayList == null) {
						arrayList = new ArrayList<Page>();
						if (arrayListList.size() < 5)
							arrayListList.add(arrayList);
					}
					arrayList.add(page);
					popNums++;
				}
			}

			// ɾ��page500ǰ100��Ԫ��
			if (size >= 100)
				for (int i = 0; i < 100; i++)
					page500.remove(0);
			else
				for (int i = 0; i < size; i++)
					page500.remove(0);
		}
		finishFlag = true;

	}
	
	//�ҵ����Ԫ��(�ߴ�Ϊ0)�����򷵻�null
	public ArrayList<Page> findEmptyArray(ArrayList<ArrayList> arrayListList) {
		if (arrayListList == null || arrayListList.isEmpty())
			return null;
		for (int i = 0; i < arrayListList.size(); i++) {
			ArrayList arrayList = arrayListList.get(i);
			if (arrayList == null) {
				arrayList = new ArrayList<Page>();
				arrayListList.set(i, arrayList);
				return arrayListList.get(i);
			} else {
				if (arrayList.isEmpty())
					return arrayListList.get(i);
				else return null;
			}
		}
		return null;
	}

	public static ArrayList<ArrayList> getArrayListList() {
		return arrayListList;
	}

	public static void setArrayListList(ArrayList<ArrayList> arrayListList) {
		KeepBufferOptimizeSQL.arrayListList = arrayListList;
	}

	public PageCRUD getDbToFilterUtil() {
		return dbToFilterUtil;
	}

	public void setDbToFilterUtil(PageCRUD dbToFilterUtil) {
		this.dbToFilterUtil = dbToFilterUtil;
	}

	public static int getPopNums() {
		return popNums;
	}

	public static void setPopNums(int popNums) {
		KeepBufferOptimizeSQL.popNums = popNums;
	}

	public static boolean isFinishFlag() {
		return finishFlag;
	}

	public static void setFinishFlag(boolean finishFlag) {
		KeepBufferPageFilterSQL.finishFlag = finishFlag;
	}

	public ArrayList<NodeClass> delOtherTag(ArrayList<NodeClass> nodeList) {
		if (nodeList == null)
			return null;
		ArrayList<NodeClass> tempArrayList = new ArrayList<NodeClass>();
		for (int i = 0; i < nodeList.size(); i++)
			if (("div".equals(nodeList.get(i).getNode().nodeName())
					&& nodeList.get(i).getNode().attr("class") != null)) {
				tempArrayList.add(nodeList.get(i));
			}
		nodeList = tempArrayList;
		return nodeList;
	}
}
