package com.hctc.parse.filter;

import org.apache.commons.lang3.StringUtils;
import org.jsoup.nodes.Node;
import org.jsoup.nodes.TextNode;

public class TagFilter {
	
	
	
	// ɾ�����ñ�ǩ(�^�V)
	public  void removeComments(Node node) {
		for (int i = 0; i < node.childNodeSize();) {
			Node child = node.childNode(i);
			String content=null;
			if ("#text".equals(child.nodeName())) {// ȥ���ı��е�&nbsp���ո�;
				TextNode ele=(TextNode) child;
				content = ele.text();
				if (content.contains("&nbsp;"))
					content = content.replaceAll("&nbsp;", "");
				content=content.trim();
				content=StringUtils.deleteWhitespace(content);
				ele.text(content);
			}
			//ȥ������Ҫ�ı�ǩ
			if ("#comment".equals(child.nodeName()) || "head".equals(child.nodeName())
					|| "title".equals(child.nodeName()) || "meta".equals(child.nodeName())
					|| "script".equals(child.nodeName()) || "style".equals(child.nodeName())
					|| "#doctype".equals(child.nodeName()) || "br".equals(child.nodeName())
					|| "img".equals(child.nodeName()) || "input".equals(child.nodeName())
					|| "embed".equals(child.nodeName()) || "object".equals(child.nodeName())
					|| "param".equals(child.nodeName()) || "area".equals(child.nodeName())
					|| "select".equals(child.nodeName()) || "option".equals(child.nodeName())
					|| ("#text".equals(child.nodeName())&&(content==null||content.length()==0))) {
					child.remove();
					//System.out.println("delete"+child.nodeName()+"========="+i+"  ");
			} else {
				removeComments(child);	
				i++;
			}
			
		}
	}
	
	
}
