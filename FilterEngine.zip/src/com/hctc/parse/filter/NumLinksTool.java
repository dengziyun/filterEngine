package com.hctc.parse.filter;

import java.util.ArrayList;
import org.jsoup.nodes.Node;

public class NumLinksTool {
	public ArrayList<NodeClass> nodeList;// �ڵ��б�

	public NumLinksTool() {
		super();
	}

	public NumLinksTool(Node node) {
		nodeList = new ArrayList<NodeClass>();
		traverNode(node);
	}
	
	public void configNodeList(Node node){
		nodeList = new ArrayList<NodeClass>();
		traverNode(node);
	}

	// �������н�����������Ҷ���ı�������ݡ����ӱ�
	public void caculateLinks() {
		if (nodeList == null)
			return;
		for (int i = 0; i < nodeList.size(); i++) {
			NodeClass node = nodeList.get(i);
			node.links = caculateNumLinks(node.getNode());
			node.childTextNumAll = caculateChildNodes(node.getNode());
			if (node.childTextNumAll != 0)
				node.linkRatio = (float) node.links / (float) node.childTextNumAll;
		}

	}

	// ����һ������Ҷ���ı������
	public int caculateChildNodes(Node iNode) {
		int nodes = 0;
		if (iNode == null)
			return nodes;
		int childNodeNum = iNode.childNodeSize();
		if (childNodeNum == 0) {
			if ("#text".equals(iNode.nodeName().toString()))
				nodes++;
			return nodes;
		}
		for (int i = 0; i < childNodeNum; i++) {
			nodes += caculateChildNodes(iNode.childNode(i));
		}
		return nodes;
	}

	// ����һ������������
	public int caculateNumLinks(Node iNode) {
		int links = 0;
		if (iNode == null)
			return links;
		int childNodeNum = iNode.childNodeSize();
		if (childNodeNum == 0)
			return links;
		for (int i = 0; i < childNodeNum; i++) {
			if (iNode.childNode(i) != null)
				links += caculateNumLinks(iNode.childNode(i));
		}
		if (isLink(iNode))
			links++;
		return links;
	}

	// �жϸýڵ��Ƿ�������
	public boolean isLink(Node iNode) {
		if ("a".equals(iNode.nodeName()))
			return true;
		else
			return false;
	}

	// ����һ���ڵ�������α���������nodeArray
	public void traverNode(Node node) {
		if (node == null)
			return;
		// ��nodeArray�м��뵱ǰ�ڵ�
		NodeClass newNode = new NodeClass();
		newNode.setNode(node);
		newNode.setLinkRatio(0f);
		newNode.setLinks(0);
		newNode.setChildTextNumAll(0);
		nodeList.add(newNode);
		// ��α���
		for (int i = 0; i < node.childNodeSize(); i++) {
			traverNode(node.childNode(i));
		}
	}

	public ArrayList<NodeClass> getNodeList() {
		return nodeList;
	}

	public void setNodeList(ArrayList<NodeClass> nodeList) {
		this.nodeList = nodeList;
	}

}
