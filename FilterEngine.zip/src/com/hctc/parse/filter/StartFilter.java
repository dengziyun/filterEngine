package com.hctc.parse.filter;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Attribute;
import org.jsoup.nodes.Attributes;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;
import com.gargoylesoftware.htmlunit.NicelyResynchronizingAjaxController;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebResponse;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlPage;

public class StartFilter {

	public static void main(String[] args) {
		String url = "https://www.jd.com/2495021.html";
		// url = "http://www.jd.cn/";
		/*
		 * WebClient wc=new WebClient(BrowserVersion.FIREFOX_52);
		 * wc.setJavaScriptTimeout(5000);
		 * wc.getOptions().setThrowExceptionOnScriptError(false);
		 * wc.getOptions().setUseInsecureSSL(true);//�����κ��������� �����Ƿ�����Ч֤��
		 * wc.getOptions().setCssEnabled(false);//����css֧��
		 * wc.getOptions().setThrowExceptionOnScriptError(false);//js���д���ʱ���׳��쳣
		 * wc.getOptions().setTimeout(100000);//�������ӳ�ʱʱ��
		 * wc.getOptions().setJavaScriptEnabled(true);//����֧��javascript�ű�
		 * wc.setAjaxController(new NicelyResynchronizingAjaxController()); //
		 * wc.getOptions().set wc.getOptions().setDoNotTrackEnabled(false);
		 * wc.setJavaScriptTimeout(10000);//����JSִ�еĳ�ʱʱ��
		 * wc.waitForBackgroundJavaScript(30000);//����JS��̨�ȴ�ִ��ʱ�� HtmlPage page =
		 * null; try { page = wc.getPage(url);
		 * 
		 * } catch (FailingHttpStatusCodeException e1) { e1.printStackTrace(); }
		 * catch (MalformedURLException e1) { e1.printStackTrace(); } catch
		 * (IOException e1) { e1.printStackTrace(); }
		 * //page.getElementByName("span");
		 * 
		 * 
		 * 
		 * HtmlPage resultPage = page; HtmlElement resultData = (HtmlElement)
		 * resultPage.getElementsById("summary-wrap").get(0); List<HtmlElement>
		 * columns = resultData.getElementsByAttribute("span", "class",
		 * "price J-p-p-1994507073"); //try 20 times to wait .5 second each for
		 * filling the page. //Element div =
		 * resultDataselect("span[class=price J-p-p-1994507073]").first();
		 * //String productPrice =price.attr("data-price"); //�õ���Ʒ�۸� for (int i
		 * = 0; i < 10; i++) {
		 * System.out.println("+++"+(!columns.get(0).asText().equals(".00")));
		 * System.out.println("+++"+columns.get(0).asText()); if
		 * ((!columns.get(0).asText().equals(".00"))&&!columns.get(0).asText().
		 * trim().equals("")) { //logger.info("�ȴ�ajaxִ�����");
		 * System.out.println("�ȴ�ajaxִ�����"); break; } synchronized (resultPage)
		 * { try { page.wait(500); } catch (InterruptedException e) {
		 * e.printStackTrace(); } } } System.out.println(resultData.asText());
		 * System.out.println("***"+columns.get(0).asText());
		 * 
		 * WebClient client = new WebClient(); try { Page pagejson =
		 * client.getPage("http://p.3.cn/prices/mgets?skuIds=J_1994507073");
		 * WebResponse response = pagejson.getWebResponse(); if
		 * (response.getContentType().equals("application/json")) { String json
		 * = response.getContentAsString(); // Map<String, String> map = new
		 * Json().fromJson(json, new TypeToken<Map<String, String>>()
		 * {}.getType()); System.out.println(json); } } catch
		 * (FailingHttpStatusCodeException e) { // TODO Auto-generated catch
		 * block e.printStackTrace(); } catch (MalformedURLException e) { //
		 * TODO Auto-generated catch block e.printStackTrace(); } catch
		 * (IOException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); }
		 */
		/*
		 * url="http://p.3.cn/prices/mgets?skuIds=J_1994507073"; try { page =
		 * wc.getPage(url); System.out.println(page.asText()); } catch
		 * (FailingHttpStatusCodeException e) { // TODO Auto-generated catch
		 * block e.printStackTrace(); } catch (MalformedURLException e) { //
		 * TODO Auto-generated catch block e.printStackTrace(); } catch
		 * (IOException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); }
		 */

		/*
		 * String res=resultPage.asText(); System.out.println(res);
		 */
		// =======================================
		// =====���˱�ǩ����������ӱ�=====
		Document doc = null;
		// doc=Jsoup.parse(url,"UTF-8");
		String url2 = new String("https://item.jd.com/11946360.html");
		url= new String("https://item.jd.com/11946360.html");
		//url = new String("http://www.jd.com");
		Document doc2 = null;
		try {
			doc = Jsoup.connect(url).userAgent("jsoup").timeout(3000).post();
			doc2 = Jsoup.connect(url2).userAgent("jsoup").timeout(3000).post();
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (doc != null && doc2 != null) {
			Node nodeDoc = (Node) doc;
			Node nodeDoc2 = (Node) doc2;
			// ��ǩ����
			TagFilter tagFilter = new TagFilter();
			tagFilter.removeComments(nodeDoc);
			tagFilter.removeComments(nodeDoc2);
			//System.out.println(nodeDoc.toString());
			// ������ǩ��������ӱ�
			NumLinksTool linksTool = new NumLinksTool(nodeDoc);
			linksTool.caculateLinks();
			NumLinksTool linksTool2 = new NumLinksTool(nodeDoc2);
			linksTool2.caculateLinks();
			ArrayList<NodeClass> nodeList1 = linksTool.getNodeList();
			/*
			for (int i = 0; linksTool.getNodeList() != null && i < linksTool.getNodeList().size(); i++) {
				Node node = linksTool.getNodeList().get(i).getNode();
				System.out.println(node.nodeName());
			}
			*/
			ArrayList<NodeClass> nodeList2 = linksTool2.getNodeList();
			
			
			for (int i = 0; linksTool.getNodeList() != null && i < linksTool.getNodeList().size(); i++) {
				Node node = linksTool.getNodeList().get(i).getNode();
				if ("crumb-wrap".equals(node.attr("class"))) {
					System.out.println(node.nodeName() + ":" + linksTool.getNodeList().get(i).getLinks() + ":"
							+ linksTool.getNodeList().get(i).getChildTextNumAll() + ":"
							+ linksTool.getNodeList().get(i).getLinkRatio() + ":class=" + node.attr("class"));
					// System.out.println(node.toString());
					System.out.println("============================================================================");
					NodeTool nl=new NodeTool();
					nl.traverNode(node,0);
					System.out.println("============================================================================");
				}

			}
			// ȷ���м۸�&&����&&����
			NodeTool nodeTool = new NodeTool();
			// System.out.println(doc.toString());
			//System.out.println(nodeTool.isContainsKeyWords(doc.toString()));
			// ȷ���Ƿ�����Ʒ��������������ʾ��Ʒ�ķ�����Ϣ
			//System.out.println(nodeTool.isContainNavigator(linksTool.getNodeList()));
			//�������ƶ�
			//nodeTool.longestCommomSubSequence(nodeList1, nodeList2);

		}

	}

}
