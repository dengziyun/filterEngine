package com.hctc.parse.filter;

import org.jsoup.nodes.Node;

public class NodeClass {
	public Node node;
	public int links;//����µ�������
	public float linkRatio;//���ӱ�
	public int childTextNumAll;//�����ӽ�����������в��
	public int level;//�����
	public String path;//���·��
	
	public NodeClass() {
		this.links = 0;
		this.linkRatio = 0f;
		this.level=0;
	}
	public Node getNode() {
		return node;
	}
	public void setNode(Node node) {
		this.node = node;
	}
	public int getLinks() {
		return links;
	}
	public void setLinks(int links) {
		this.links = links;
	}
	public float getLinkRatio() {
		return linkRatio;
	}
	public void setLinkRatio(float linkRatio) {
		this.linkRatio = linkRatio;
	}
	public int getChildTextNumAll() {
		return childTextNumAll;
	}
	public void setChildTextNumAll(int childTextNumAll) {
		this.childTextNumAll = childTextNumAll;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	
}
