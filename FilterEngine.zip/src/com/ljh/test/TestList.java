package com.ljh.test;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedList;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Node;

import com.hctc.crawler.common.CommUtil;
import com.hctc.crawler.common.LinkedListListOp;
import com.hctc.crawler.common.Page;
import com.hctc.crawler.db.PageCRUD;
import com.hctc.parse.filter.NodeClass;
import com.hctc.parse.filter.NodeTool;

public class TestList {

	public static void main(String[] args) throws IOException {
		String url1="https://item.jd.com/6813556.html";
		String url2="https://item.jd.com/25756244796.html";
		// url2="https://www.jd.com";
		URL urlurl1=new URL(url1);
		URL urlurl2=new URL(url2);
		Document doc1=Jsoup.parse(urlurl1,5000);
		Document doc2=Jsoup.parse(urlurl2,5000);
		NodeTool tool=new NodeTool();
		ArrayList<NodeClass> nodeList1=new ArrayList<NodeClass>();
		ArrayList<NodeClass> nodeList2=new ArrayList<NodeClass>();
		tool.obtainTreeList(nodeList1, doc1, 0);
		tool.obtainTreeList(nodeList2, doc2, 0);
		//tool.longestCommomSubSequence(nodeList1, nodeList2);
		int j=0;
		for(int i=0;i<nodeList1.size();i++)
			if(("div".equals(nodeList1.get(i).getNode().nodeName())&&nodeList1.get(i).getNode().attr("class")!=null)
					||("span".equals(nodeList1.get(i).getNode().nodeName())&&nodeList1.get(i).getNode().attr("class")!=null)){
				j++;
				//System.out.println(nodeList1.get(i).getNode().attr("class"));
			}
		System.out.println("====div+class|span:"+j+"====all:"+nodeList1.size());
		j=0;
		for(int i=0;i<nodeList2.size();i++)
			if(("div".equals(nodeList2.get(i).getNode().nodeName())&&nodeList2.get(i).getNode().attr("class")!=null)
					||("span".equals(nodeList2.get(i).getNode().nodeName())&&nodeList2.get(i).getNode().attr("class")!=null)){
				j++;
				//System.out.println(nodeList2.get(i).getNode().attr("class"));
			}
		System.out.println("====div+class|span:"+j+"====all:"+nodeList2.size());
		ArrayList<NodeClass> tempArrayList=new ArrayList<NodeClass>();
		for(int i=0;i<nodeList1.size();i++)
			if(("div".equals(nodeList1.get(i).getNode().nodeName())&&nodeList1.get(i).getNode().attr("class")!=null)
					||("span".equals(nodeList1.get(i).getNode().nodeName())&&nodeList1.get(i).getNode().attr("class")!=null)){
				tempArrayList.add(nodeList1.get(i));
			}
		nodeList1=tempArrayList;
		tempArrayList=new ArrayList<NodeClass>();
		for(int i=0;i<nodeList2.size();i++)
			if(("div".equals(nodeList2.get(i).getNode().nodeName())&&nodeList2.get(i).getNode().attr("class")!=null)
					||("span".equals(nodeList2.get(i).getNode().nodeName())&&nodeList2.get(i).getNode().attr("class")!=null)){
				tempArrayList.add(nodeList2.get(i));
			}
		nodeList2=tempArrayList;
		System.out.println(tool.longestCommomSubSequence(nodeList1, nodeList2)+"=="+nodeList1.size()+"===="+nodeList2.size());
		//ArrayList<Page> page500 = new ArrayList<Page>();
		//PageCRUD dbToFilterUtil=new PageCRUD();
		//page500 = dbToFilterUtil.getKMItems(k);
		
		/*
		String url="https://shouji.jd.com/43543543546456456456456.html";
		url="https://item.jd.com/6813556.html";
		//System.out.println(CommUtil.isGoodsUrl(url));
		Node node=CommUtil.obtainJsoupNode();
		//Node node2=CommUtil.obtainJsoupNode();
		//System.out.println(node);
		NodeTool tool=new NodeTool();
		//tool.traverNode(node, 0);
		System.out.println();
		URL urlurl=new URL(url);
		Document doc=Jsoup.parse(urlurl,3000);
		System.out.println(tool.containsTree(doc,node));
		//tool.traverNode(doc, 0);
		 * /
		/*
		ArrayList array=null;
		if(array==null) array=new ArrayList();
		array.add("test1");
		array.add("test2");
		array.add("test3");
		array.add("test4");
		System.out.println(array.isEmpty());
		System.out.println(array.get(0));
		array.remove(0);
		array.remove(0);
		array.remove(0);
		array.set(0, null);
		
		System.out.println(array.get(0)+"====");
		for (int i = 0; i < 10; i++) {
			if (array == null)
				array.add("test"+i);
			if (array.size() <= 10 || array.get(i)==null)
				array.add("test"+i);
		}
		for(int i=0;i<array.size();i++){
			System.out.println(array.get(i));
		}
		*/
		
		//LinkedList<LinkedList> listList = new LinkedList<LinkedList>();
		/*LinkedList list1=new LinkedList<String>();
		list1.add(new String("1-111"));
		listList.add(list1);
		LinkedList list2=new LinkedList<String>();
		list2.add(new String("2-111"));
		listList.add(list2);*/
		//LinkedListListOp listop=new LinkedListListOp();
		//System.out.println(listop.findShortestLinkedList(listList));
		//if(listop.findShortestLinkedList(listList)!=null) System.out.println(listop.findShortestLinkedList(listList).size());
		/*
		for(int i=0;i<10;i++){
			if(listList==null)  listList.addLast(new LinkedList<String>());
			if(listList.size()<10) listList.addLast(new LinkedList<String>());
		}
		for(int i=0;i<10;i++){
			if(listList.get(i)==null) listList.addLast(new LinkedList<String>());
		}
		System.out.println(listList.size()+"==============");
		for(int i=0;i<10;i++){
			System.out.println(listList.get(i).size());
		}
		*/
	}

}
