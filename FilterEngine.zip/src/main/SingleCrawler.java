package main;

import java.io.IOException;
import java.util.Date;

import org.apache.http.client.ClientProtocolException;

import com.hctc.crawler.common.CommRef;
import com.hctc.crawler.common.CommUtil;
import com.hctc.crawler.common.DBUtil;
import com.hctc.crawler.common.Page;
import com.hctc.crawler.page.DownPage;
import com.hctc.crawler.page.PageUtil;

public class SingleCrawler {
	public DownPage down;
	public CommRef commRef;

	public  void start() throws ClientProtocolException, IOException {
		/*down.setPageUrl("http://club.jr.jd.com/quant/myTopics?userName=5Mq7jNbI05rtpyvZ5G4BKQ%3D%3D");
		down.downPage();*/
		String pageStr=new String();
		String logStr=new String();
		long a = new Date().getTime();
		long b = new Date().getTime();
		if(commRef.dbTodoUtil.count()==0){
			logStr=new String("ʱ���*��������*ʱ��*��ַ*���*�ѷ�����Ч��ַ��");
			CommUtil.writeLogALine(logStr);
			pageStr=commRef.firstUrl;
			logStr=new String("firstpage");
			a = new Date().getTime();
			down.setPageUrl(pageStr);
			down.downPage();
			b = new Date().getTime();
			logStr=logStr+"*"+(b-a)+"*"+pageStr+"*1*1";
			CommUtil.writeLogALine(logStr);
		}
		for(int i=0;i<100000;i++){
			pageStr = commRef.dbTodoUtil.getFirstItem();
			if(pageStr!=null&&!pageStr.isEmpty()){
				System.out.println(pageStr);
				logStr=new String("otherpage*");
				a = new Date().getTime();
				down.setPageUrl(pageStr);
				//System.out.println("����todo:"+pageStr);
				down.downPage();
				//System.out.println("ɾ��todo:"+pageStr);
				commRef.dbTodoUtil.deleteFromDatabase(pageStr);
				b = new Date().getTime();
				logStr=logStr+(b-a)+"*"+pageStr+"*"+(i+2)+"*"+commRef.dbVisitedUtil.count();
				CommUtil.writeLogALine(logStr);
				System.out.println("=========todo:"+commRef.dbTodoUtil.count()
						+"=========visited:"+commRef.dbVisitedUtil.count());
				
			}
			
		}
		
	}
	
	public DownPage getDown() {
		return down;
	}
	public void setDown(DownPage down) {
		this.down = down;
	}

	public CommRef getCommRef() {
		return commRef;
	}

	public void setCommRef(CommRef commRef) {
		this.commRef = commRef;
	}

}
