package main;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class StartSingleCrawler {

	public static void main(String[] args) throws ClientProtocolException, IOException {
		ApplicationContext contextSingle = new ClassPathXmlApplicationContext("main/BeanConfig.xml");
		SingleCrawler singleCrawler= contextSingle.getBean("singleCrawler", SingleCrawler.class);
		singleCrawler.start();
	}

}
